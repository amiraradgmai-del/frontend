from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="TAX_AI_",
        case_sensitive=False,
        extra="ignore",
    )

    app_name: str = "Tax AI Advisor API"
    app_version: str = "0.1.0"
    environment: Literal["development", "test", "staging", "production"] = "development"
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    docs_enabled: bool = True
    database_url: str
    readiness_timeout_seconds: float = Field(default=2.0, ge=0.1, le=10.0)
    jwt_secret: str = Field(min_length=32)
    jwt_algorithm: Literal["HS256", "HS384", "HS512"] = "HS256"
    jwt_issuer: str = "tax-ai-advisor"
    jwt_audience: str = "tax-ai-advisor-api"
    access_token_minutes: int = Field(default=15, ge=1, le=60)
    refresh_token_days: int = Field(default=30, ge=1, le=90)
    max_failed_logins: int = Field(default=5, ge=3, le=20)
    login_lock_minutes: int = Field(default=15, ge=1, le=1440)
    verification_code_minutes: int = Field(default=10, ge=2, le=30)
    verification_resend_seconds: int = Field(default=60, ge=30, le=600)
    verification_max_attempts: int = Field(default=5, ge=3, le=10)
    password_setup_minutes: int = Field(default=20, ge=5, le=60)
    email_delivery_mode: Literal["console", "smtp"] = "console"
    smtp_host: str | None = None
    smtp_port: int = Field(default=587, ge=1, le=65535)
    smtp_username: str | None = None
    smtp_password: str | None = None
    smtp_from_email: str | None = None
    smtp_from_name: str = "Tax AI Advisor"
    smtp_use_tls: bool = True
    max_upload_bytes: int = Field(
        default=20 * 1024 * 1024, ge=1024, le=100 * 1024 * 1024
    )
    storage_backend: Literal["local", "s3"] = "local"
    local_storage_path: str = "./storage"
    s3_endpoint_url: str | None = None
    s3_bucket: str = "tax-ai-documents"
    s3_access_key: str | None = None
    s3_secret_key: str | None = None
    s3_region: str = "us-east-1"
    celery_broker_url: str = "redis://localhost:6379/0"
    celery_result_backend: str = "redis://localhost:6379/1"
    chunk_max_chars: int = Field(default=1400, ge=500, le=4000)
    chunk_overlap_chars: int = Field(default=160, ge=0, le=500)
    minimum_extracted_chars: int = Field(default=40, ge=1, le=1000)
    ai_provider: Literal["disabled", "gemini"] = "gemini"
    gemini_api_key: str | None = None
    gemini_generation_model: str = "gemini-2.5-flash"
    gemini_embedding_model: str = "gemini-embedding-001"
    gemini_timeout_seconds: float = Field(default=20.0, ge=1.0, le=60.0)
    embedding_dimensions: int = Field(default=768, ge=128, le=3072)
    bootstrap_admin_email: str | None = None
    bootstrap_admin_password: str | None = None
    bootstrap_admin_full_name: str = "مدیر سامانه"

    @field_validator("docs_enabled")
    @classmethod
    def disable_docs_in_production_by_default(cls, value: bool, info):
        environment = info.data.get("environment")
        if environment == "production" and value:
            return False
        return value

    @field_validator("gemini_api_key", mode="before")
    @classmethod
    def normalize_gemini_api_key(cls, value):
        if value is None or not str(value).strip():
            return None
        cleaned = str(value).strip()
        if len(cleaned) < 20:
            raise ValueError("Gemini API key is too short")
        return cleaned

    @field_validator("bootstrap_admin_email", "bootstrap_admin_password", mode="before")
    @classmethod
    def normalize_optional_bootstrap_value(cls, value):
        if value is None or not str(value).strip():
            return None
        return str(value).strip()

    @field_validator(
        "smtp_host", "smtp_username", "smtp_password", "smtp_from_email", mode="before"
    )
    @classmethod
    def normalize_optional_smtp_value(cls, value):
        if value is None or not str(value).strip():
            return None
        return str(value).strip()

    @model_validator(mode="after")
    def validate_storage_settings(self):
        if self.chunk_overlap_chars >= self.chunk_max_chars:
            raise ValueError("chunk_overlap_chars must be smaller than chunk_max_chars")
        if self.storage_backend == "s3" and not all(
            (
                self.s3_endpoint_url,
                self.s3_access_key,
                self.s3_secret_key,
                self.s3_bucket,
            )
        ):
            raise ValueError(
                "S3 storage requires endpoint, bucket, access key and secret key"
            )
        if bool(self.bootstrap_admin_email) != bool(self.bootstrap_admin_password):
            raise ValueError("Bootstrap admin email and password must be set together")
        if self.bootstrap_admin_password:
            password = self.bootstrap_admin_password
            if len(password) < 12 or not all(
                (
                    any(char.islower() for char in password),
                    any(char.isupper() for char in password),
                    any(char.isdigit() for char in password),
                )
            ):
                raise ValueError("Bootstrap admin password must be strong")
        if self.email_delivery_mode == "smtp" and not all(
            (self.smtp_host, self.smtp_username, self.smtp_password, self.smtp_from_email)
        ):
            raise ValueError("SMTP delivery requires host, username, password and from email")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
