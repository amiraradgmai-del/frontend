from __future__ import annotations

import logging
import smtplib
from email.message import EmailMessage
from email.utils import formataddr

from app.core.config import Settings

logger = logging.getLogger(__name__)


class EmailDeliveryError(RuntimeError):
    pass


class EmailSender:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def send_verification_code(self, email: str, first_name: str, code: str) -> None:
        if self.settings.email_delivery_mode == "console":
            logger.warning("Development verification code for %s: %s", email, code)
            return

        message = EmailMessage()
        message["Subject"] = "کد تأیید ایمیل شما"
        message["From"] = formataddr(
            (self.settings.smtp_from_name, self.settings.smtp_from_email or "")
        )
        message["To"] = email
        message.set_content(
            f"""سلام {first_name} عزیز،

به چکا، دستیار هوشمند مالیاتی خوش آمدید.

کد تأیید ایمیل شما: {code}

این کد تا {self.settings.verification_code_minutes} دقیقه معتبر است. این کد را در اختیار هیچ‌کس قرار ندهید. تیم پشتیبانی هرگز کد تأیید یا رمز عبور شما را درخواست نمی‌کند.

اگر شما این درخواست را ثبت نکرده‌اید، این پیام را نادیده بگیرید.
"""
        )
        try:
            with smtplib.SMTP(
                self.settings.smtp_host, self.settings.smtp_port, timeout=15
            ) as smtp:
                if self.settings.smtp_use_tls:
                    smtp.starttls()
                smtp.login(self.settings.smtp_username, self.settings.smtp_password)
                smtp.send_message(message)
        except (OSError, smtplib.SMTPException) as error:
            raise EmailDeliveryError("Verification email could not be sent") from error
