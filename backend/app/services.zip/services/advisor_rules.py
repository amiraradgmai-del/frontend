from __future__ import annotations

from dataclasses import dataclass

from app.documents.text import normalize_persian

PROHIBITED_TERMS = {
    "فرار مالیاتی": "tax_evasion",
    "فاکتور صوری": "fake_invoice",
    "پنهان کردن درآمد": "income_concealment",
    "پنهان‌کردن درآمد": "income_concealment",
    "ثبت اطلاعات خلاف واقع": "false_information",
    "دور زدن مالیات": "tax_evasion",
    "دورزدن مالیات": "tax_evasion",
}
SENSITIVE_TERMS = {
    "برگ تشخیص": "assessment_notice",
    "ابلاغ": "official_notice",
    "اعتراض": "appeal",
    "هیئت حل اختلاف": "tax_dispute_board",
    "اجرائیه": "enforcement_order",
    "لایحه": "legal_brief",
    "بدهی": "tax_debt",
    "قرارداد": "contract_review",
}
DEADLINE_TERMS = {"مهلت", "تا چه تاریخی", "چند روز", "اعتراض"}
SOURCE_REQUIRED_TERMS = {
    "ماده", "تبصره", "بند", "نرخ", "درصد", "مبلغ", "مهلت", "جریمه",
    "معافیت", "نصاب", "بخشنامه", "رأی", "رای", "جدیدترین", "آخرین",
    "امروز", "امسال", "سال", "تاریخ", "قانون فعلی",
}
TAX_TERMS = {
    "مالیات", "مالیاتی", "اظهارنامه", "مودی", "مؤدی", "ارزش افزوده",
    "صورتحساب", "سامانه مودیان", "درگاه مالیاتی", "بخشودگی", "جرایم",
    "درآمد", "هزینه قابل قبول", "دفاتر قانونی", "کد اقتصادی", "تکالیف",
}


@dataclass(frozen=True)
class RuleResult:
    prohibited_reason: str | None
    escalation_reasons: list[str]
    clarifying_questions: list[str]
    out_of_scope: bool
    source_required: bool
    casual_answer: str | None

    @property
    def needs_expert(self) -> bool:
        return bool(self.escalation_reasons)


def evaluate_question(question: str) -> RuleResult:
    normalized = normalize_persian(question).lower()
    casual_answer = detect_casual_response(normalized)
    prohibited_reason = next(
        (reason for phrase, reason in PROHIBITED_TERMS.items() if phrase in normalized),
        None,
    )
    escalation_reasons = sorted(
        {reason for phrase, reason in SENSITIVE_TERMS.items() if phrase in normalized}
    )
    tax_related = any(term in normalized for term in TAX_TERMS)
    source_required = any(term in normalized for term in SOURCE_REQUIRED_TERMS) or any(
        char.isdigit() for char in normalized
    )
    out_of_scope = casual_answer is None and not tax_related
    questions: list[str] = []
    if any(term in normalized for term in DEADLINE_TERMS):
        if not any(char.isdigit() for char in normalized):
            questions.append("تاریخ رویداد یا ابلاغ موردنظر چیست؟")
        questions.append("نوع مؤدی و دوره مالیاتی را مشخص می‌کنید؟")
    if "جریمه" in normalized and not any(char.isdigit() for char in normalized):
        questions.append("نوع جریمه و دوره مالیاتی موردنظر چیست؟")
    return RuleResult(
        prohibited_reason=prohibited_reason,
        escalation_reasons=escalation_reasons,
        clarifying_questions=list(dict.fromkeys(questions)),
        out_of_scope=out_of_scope,
        source_required=source_required,
        casual_answer=casual_answer,
    )


def detect_casual_response(normalized: str) -> str | None:
    compact = normalized.strip(" ؟?!،,.\n\t")
    if compact.startswith(("سلام", "درود", "صبح بخیر", "عصر بخیر", "شب بخیر")):
        return "سلام! خوش آمدید. درباره موضوعات مالیاتی، اظهارنامه، ارزش افزوده یا سامانه مؤدیان چه کمکی از من برمی‌آید؟"
    if compact.startswith(("ممنون", "مرسی", "سپاس")):
        return "خواهش می‌کنم. اگر پرسش مالیاتی دیگری دارید، در خدمتم."
    if compact.startswith(("خداحافظ", "فعلا", "فعلاً")):
        return "خدانگهدار؛ هر زمان پرسش مالیاتی داشتید، در خدمتم."
    if "تو کی هستی" in compact or "شما کی هستید" in compact:
        return "من چکا، دستیار هوشمند مالیاتی هستم؛ پاسخ‌های مستند را از بانک دانش می‌دهم و برای توضیحات عمومی کم‌ریسک نیز به‌صورت کنترل‌شده کمک می‌کنم."
    if compact in {"خوبی", "حالت چطوره", "چه خبر"}:
        return "ممنون، آماده‌ام کمک کنم. سؤال مالیاتی‌تان را بنویسید."
    return None
