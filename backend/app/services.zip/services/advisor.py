from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, timezone

from sqlalchemy.orm import Session

from app.documents.text import normalize_persian
from app.models.advisor import Conversation
from app.models.auth import User
from app.models.documents import DocumentChunk
from app.models.portal import LawReferenceRecord
from app.repositories.advisor import AdvisorRepository
from app.repositories.auth import AuthRepository
from app.schemas.advisor import AskResponse, CitationResponse
from app.services.advisor_rules import evaluate_question
from app.services.site import get_ai_policy
from app.ai.providers import AnswerProvider, DisabledAIProvider, EmbeddingProvider, cosine_similarity

DISCLAIMER = "این پاسخ صرفاً اطلاعات عمومی است و جایگزین مشاوره تخصصی مالیاتی نیست."
STOP_WORDS = {"از", "به", "در", "با", "برای", "که", "این", "آن", "را", "و", "یا", "چیست", "است", "شود"}


class ConversationNotFoundError(Exception):
    pass


class MessageNotFoundError(Exception):
    pass


@dataclass(frozen=True)
class SearchHit:
    chunk: DocumentChunk
    score: float


@dataclass(frozen=True)
class LawHit:
    record: LawReferenceRecord
    score: float


def terms(text: str) -> set[str]:
    return {token for token in re.findall(r"[\w\u0600-\u06ff]+", normalize_persian(text).lower()) if len(token) > 1 and token not in STOP_WORDS}


class AdvisorService:
    def __init__(
        self,
        session: Session,
        provider: AnswerProvider | EmbeddingProvider | None = None,
    ) -> None:
        self.session = session
        self.repository = AdvisorRepository(session)
        self.audit = AuthRepository(session)
        self.provider = provider or DisabledAIProvider()

    def search(
        self,
        question: str,
        *,
        as_of_date: date | None = None,
        topics: list[str] | None = None,
        limit: int = 5,
    ) -> list[SearchHit]:
        query_terms = terms(question)
        if not query_terms:
            return []
        hits = []
        query_vector = self.provider.embed_query(question)
        for chunk in self.repository.active_chunks(
            as_of_date=as_of_date, topics=topics
        ):
            chunk_terms = terms(chunk.content)
            overlap = query_terms & chunk_terms
            semantic_score = (
                cosine_similarity(query_vector, chunk.embedding_json)
                if query_vector is not None and chunk.embedding_json
                else 0.0
            )
            if overlap or semantic_score > 0.25:
                lexical_score = len(overlap) / len(query_terms) + len(overlap) / max(len(chunk_terms), 1)
                score = (0.65 * lexical_score) + (0.35 * max(semantic_score, 0.0))
                if chunk.article_number and chunk.article_number in question:
                    score += 0.5
                hits.append(SearchHit(chunk, min(score, 1.0)))
        return sorted(hits, key=lambda hit: hit.score, reverse=True)[:limit]

    def search_law_records(self, question: str, limit: int = 3) -> list[LawHit]:
        query_terms = terms(question)
        if not query_terms:
            return []
        hits: list[LawHit] = []
        for record in self.session.query(LawReferenceRecord).all():
            record_terms = terms(
                f"{record.law_name} {record.chapter} {record.article_number} "
                f"{record.keywords} {record.official_text}"
            )
            overlap = query_terms & record_terms
            if not overlap:
                continue
            score = len(overlap) / len(query_terms)
            if record.article_number and record.article_number in question:
                score += 0.6
            hits.append(LawHit(record=record, score=min(score, 1.0)))
        return sorted(hits, key=lambda hit: hit.score, reverse=True)[:limit]

    def ask(
        self,
        question: str,
        conversation_id: str | None,
        user: User,
        *,
        as_of_date: date | None = None,
        topics: list[str] | None = None,
    ) -> AskResponse:
        conversation = self._conversation(conversation_id, question, user)
        self.repository.add_message(conversation.id, "user", question)
        rules = evaluate_question(question)
        policy = get_ai_policy(self.session)
        should_search = not (
            rules.prohibited_reason
            or rules.out_of_scope
            or (rules.casual_answer and policy.casual_chat_enabled)
        )
        hits = self.search(
            question, as_of_date=as_of_date, topics=topics
        ) if should_search else []
        selected = [hit for hit in hits if hit.score >= 0.12][:2]
        law_hits = self.search_law_records(question) if should_search and not selected else []
        law_citations: list[CitationResponse] = []
        source_notice = None
        if rules.prohibited_reason:
            answer = (
                "نمی‌توانم برای فرار مالیاتی، ثبت اطلاعات خلاف واقع یا دورزدن "
                "تکالیف قانونی راهنمایی عملی ارائه کنم. از مسیر قانونی اصلاح اطلاعات "
                "یا مشاوره با متخصص مالیاتی استفاده کنید."
            )
            confidence = 0.0
            answer_basis = "refusal"
        elif rules.casual_answer and policy.casual_chat_enabled:
            answer = rules.casual_answer
            confidence = 1.0
            answer_basis = "casual"
        elif rules.out_of_scope:
            answer = (
                "من برای موضوعات مالیاتی طراحی شده‌ام. اگر پرسش مالیاتی دارید، آن را "
                "با جزئیات بنویسید تا بر اساس بانک دانش بررسی کنم."
            )
            confidence = 0.0
            answer_basis = "out_of_scope"
        elif selected:
            excerpts = [self._source_excerpt(hit.chunk) for hit in selected]
            generated = self.provider.generate(question, excerpts)
            answer = generated or self._concise_sources(excerpts)
            confidence = round(sum(hit.score for hit in selected) / len(selected), 2)
            answer_basis = "dataset"
        elif law_hits:
            law_hits = law_hits[:2]
            excerpts = [
                f"ماده {hit.record.article_number}\n{self._quote(hit.record.official_text)}"
                for hit in law_hits
            ]
            generated = self.provider.generate(question, excerpts)
            answer = generated or self._concise_sources(excerpts)
            confidence = round(sum(hit.score for hit in law_hits) / len(law_hits), 2)
            answer_basis = "dataset"
            law_citations = [
                CitationResponse(
                    chunk_id=hit.record.id,
                    article_number=hit.record.article_number,
                    score=round(hit.score, 3),
                )
                for hit in law_hits
            ]
        elif (
            policy.general_knowledge_enabled
            and policy.general_knowledge_weight > 0
            and not rules.needs_expert
            and not (policy.require_sources_for_sensitive_answers and rules.source_required)
        ):
            generated = self.provider.generate_general(question) or self._general_fallback(question)
            if generated:
                answer = generated
                confidence = round(policy.general_knowledge_weight / 100, 2)
                answer_basis = "general_knowledge"
                source_notice = (
                    "این پاسخ عمومی است و پشتوانه تأییدشده در بانک دانش چکا ندارد؛ "
                    "برای تصمیم قطعی به آن اتکا نکنید."
                )
            else:
                answer = "برای این پرسش منبع معتبر و کافی در بانک دانش پیدا نشد. لطفاً سؤال را دقیق‌تر مطرح کنید یا سند مرتبط را به بانک دانش اضافه کنید."
                confidence = 0.0
                answer_basis = "insufficient_source"
        else:
            answer = "برای این پرسش منبع معتبر و کافی در بانک دانش پیدا نشد. لطفاً سؤال را دقیق‌تر مطرح کنید یا سند مرتبط را به بانک دانش اضافه کنید."
            confidence = 0.0
            answer_basis = "insufficient_source"
        if rules.needs_expert and not rules.prohibited_reason:
            answer += "\n\nاین موضوع می‌تواند حساس یا مهلت‌دار باشد؛ بررسی کارشناس مالیاتی توصیه می‌شود."
            confidence = min(confidence, 0.6)
        if rules.clarifying_questions and not rules.prohibited_reason:
            answer += "\n\nبرای پاسخ دقیق‌تر:\n" + "\n".join(
                f"- {item}" for item in rules.clarifying_questions
            )
            confidence = min(confidence, 0.5)
        answer = self._concise(answer)
        disclaimer = "" if answer_basis == "casual" else DISCLAIMER
        assistant = self.repository.add_message(conversation.id, "assistant", answer, confidence=confidence, needs_expert=rules.needs_expert, disclaimer=disclaimer)
        citations = list(law_citations)
        for rank, hit in enumerate(hits, 1):
            is_selected = hit in selected
            self.repository.add_retrieval(assistant.id, hit.chunk, hit.score, rank, is_selected)
            if is_selected:
                quote = self._quote(hit.chunk.content)
                self.repository.add_citation(assistant.id, hit.chunk, quote, hit.score, rank)
                citations.append(CitationResponse(chunk_id=hit.chunk.id, article_number=hit.chunk.article_number, score=round(hit.score, 3)))
        self.repository.touch(conversation)
        self.audit.add_audit("advisor.question_answered", "conversation", actor_user_id=user.id, resource_id=conversation.id, metadata={"citations": len(citations), "needs_expert": rules.needs_expert, "escalation_reasons": rules.escalation_reasons, "refusal_reason": rules.prohibited_reason, "answer_basis": answer_basis, "general_knowledge_weight": policy.general_knowledge_weight if answer_basis == "general_knowledge" else 0})
        self.session.commit()
        return AskResponse(conversation_id=conversation.id, message_id=assistant.id, answer=answer, citations=citations, confidence=confidence, needs_expert=rules.needs_expert, disclaimer=disclaimer, clarifying_questions=rules.clarifying_questions, escalation_reasons=rules.escalation_reasons, refusal_reason=rules.prohibited_reason, answer_basis=answer_basis, source_notice=source_notice)

    def _conversation(self, conversation_id: str | None, question: str, user: User) -> Conversation:
        if conversation_id is None:
            return self.repository.create_conversation(user.id, question.strip()[:80])
        item = self.repository.get_conversation(conversation_id, user.id)
        if item is None:
            raise ConversationNotFoundError
        return item

    def list_conversations(self, user: User):
        return self.repository.list_conversations(user.id)

    def get_messages(self, conversation_id: str, user: User):
        item = self.repository.get_conversation(conversation_id, user.id)
        if item is None:
            raise ConversationNotFoundError
        return item.messages

    def rename(self, conversation_id: str, title: str, user: User):
        item = self.repository.get_conversation(conversation_id, user.id)
        if item is None:
            raise ConversationNotFoundError
        item.title = title.strip()
        self.repository.touch(item)
        self.session.commit()
        return item

    def delete(self, conversation_id: str, user: User) -> None:
        item = self.repository.get_conversation(conversation_id, user.id)
        if item is None:
            raise ConversationNotFoundError
        item.deleted_at = datetime.now(timezone.utc)
        self.session.commit()

    def feedback(self, message_id: str, rating: str, comment: str, user: User) -> None:
        if self.repository.get_owned_assistant_message(message_id, user.id) is None:
            raise MessageNotFoundError
        self.repository.set_feedback(message_id, user.id, rating, comment)
        self.audit.add_audit("advisor.feedback_recorded", "chat_message", actor_user_id=user.id, resource_id=message_id, metadata={"rating": rating})
        self.session.commit()

    def list_feedback(self, rating: str | None):
        return self.repository.list_feedback(rating)

    def stats(self) -> dict[str, int]:
        return self.repository.stats()

    @staticmethod
    def _quote(content: str) -> str:
        return content.strip()[:500]

    @staticmethod
    def _concise(text: str, max_chars: int = 650) -> str:
        cleaned = re.sub(r"[ \t]+", " ", text).strip()
        if len(cleaned) <= max_chars:
            return cleaned
        shortened = cleaned[:max_chars].rsplit(" ", 1)[0].rstrip("،؛:.-")
        return shortened + "…"

    @classmethod
    def _concise_sources(cls, sources: list[str]) -> str:
        summaries = []
        for source in sources[:2]:
            article = re.match(r"ماده\s+[^\n]+", source)
            body = source.split("\n", 1)[-1]
            sentences = [part.strip() for part in re.split(r"(?<=[.!؟])\s+|\n+", body) if part.strip()]
            summary = " ".join(sentences[:2])
            if article:
                summary = f"{article.group(0)}: {summary}"
            summaries.append(cls._concise(summary, 280))
        return "\n\n".join(summaries)

    @classmethod
    def _source_excerpt(cls, chunk: DocumentChunk) -> str:
        prefix = f"ماده {chunk.article_number}\n" if chunk.article_number else ""
        return prefix + cls._quote(chunk.content)

    @staticmethod
    def _general_fallback(question: str) -> str | None:
        normalized = normalize_persian(question).lower()
        responses = {
            "اظهارنامه": "اظهارنامه مالیاتی گزارش دوره‌ای مؤدی از درآمد، هزینه و اطلاعات مالی است. نوع اظهارنامه و مهلت ارسال به نوع مؤدی و دوره مالی بستگی دارد؛ برای اقدام نهایی، سال و نوع فعالیت را مشخص کنید.",
            "ارزش افزوده": "مالیات بر ارزش افزوده در زنجیره عرضه کالا و خدمات محاسبه می‌شود. تکالیف ثبت صورتحساب، گزارش دوره و پرداخت به نوع فعالیت و وضعیت مؤدی بستگی دارد.",
            "سامانه مودیان": "سامانه مؤدیان برای ثبت و تبادل صورتحساب‌های الکترونیکی و انجام بخشی از تکالیف مالیاتی استفاده می‌شود. وضعیت عضویت، حافظه مالیاتی و نوع صورتحساب باید متناسب با کسب‌وکار بررسی شود.",
            "اعتراض": "برای اعتراض مالیاتی ابتدا نوع ابلاغ، تاریخ ابلاغ و مرحله رسیدگی را مشخص کنید. متن اعتراض باید مستند، روشن و همراه با مدارک مرتبط تنظیم شود.",
            "مالیات": "مالیات پرداخت قانونی اشخاص و کسب‌وکارها بر اساس درآمد، دارایی، مصرف یا فعالیت اقتصادی است. نوع مالیات و تکالیف هر فرد به وضعیت شغلی و پرونده او بستگی دارد.",
        }
        return next((answer for keyword, answer in responses.items() if keyword in normalized), None)
