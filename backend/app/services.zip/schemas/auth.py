from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, EmailStr, Field, field_validator


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: str = Field(min_length=2, max_length=120)

    @field_validator("password")
    @classmethod
    def validate_password_strength(cls, value: str) -> str:
        if not any(char.islower() for char in value):
            raise ValueError("Password must include a lowercase letter")
        if not any(char.isupper() for char in value):
            raise ValueError("Password must include an uppercase letter")
        if not any(char.isdigit() for char in value):
            raise ValueError("Password must include a digit")
        return value

    @field_validator("full_name")
    @classmethod
    def normalize_full_name(cls, value: str) -> str:
        return " ".join(value.split())


class SignupStartRequest(BaseModel):
    first_name: str = Field(min_length=2, max_length=60)
    last_name: str = Field(min_length=2, max_length=60)
    email: EmailStr
    referral_code: str = Field(default="", max_length=16)

    @field_validator("first_name", "last_name")
    @classmethod
    def normalize_name(cls, value: str) -> str:
        return " ".join(value.split())


class SignupStartResponse(BaseModel):
    message: str
    expires_in: int
    resend_after: int


class SignupVerifyRequest(BaseModel):
    email: EmailStr
    code: str = Field(pattern=r"^\d{6}$")


class SignupVerifyResponse(BaseModel):
    setup_token: str
    expires_in: int


class SignupCompleteRequest(BaseModel):
    setup_token: str = Field(min_length=40, max_length=256)
    password: str = Field(min_length=8, max_length=128)

    @field_validator("password")
    @classmethod
    def validate_password_strength(cls, value: str) -> str:
        if not any(char.islower() for char in value):
            raise ValueError("Password must include a lowercase letter")
        if not any(char.isupper() for char in value):
            raise ValueError("Password must include an uppercase letter")
        if not any(char.isdigit() for char in value):
            raise ValueError("Password must include a digit")
        return value


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)
    otp_code: str = Field(default="", max_length=6, pattern="^$|^[0-9]{6}$")


class RefreshRequest(BaseModel):
    refresh_token: str = Field(min_length=40, max_length=256)


class LogoutRequest(RefreshRequest):
    pass


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class UserResponse(BaseModel):
    id: str
    email: str
    full_name: str
    account_tier: Literal["normal", "plus", "pro"]
    is_active: bool
    two_factor_enabled: bool
    roles: list[str]
    permissions: list[str]
    created_at: datetime


class UpdateProfileRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)

    @field_validator("full_name")
    @classmethod
    def normalize_full_name(cls, value: str) -> str:
        return " ".join(value.split())


class AdminUserUpdateRequest(BaseModel):
    account_tier: Literal["normal", "plus", "pro"] | None = None
    is_active: bool | None = None
    roles: list[Literal["user", "admin", "tax_expert", "company_expert", "system_admin"]] | None = Field(
        default=None, min_length=1, max_length=7
    )

    @field_validator("roles")
    @classmethod
    def unique_roles(cls, value: list[str] | None) -> list[str] | None:
        return sorted(set(value)) if value is not None else None
