from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class ConsultationCreateRequest(BaseModel):
    subject: str = Field(min_length=3, max_length=200)
    description: str = Field(min_length=10, max_length=5000)
    source_message_id: str | None = None
    use_wallet_if_needed: bool = False


class ConsultationUpdateRequest(BaseModel):
    status: Literal[
        "submitted", "in_review", "waiting_for_user", "resolved", "closed"
    ]
    priority: Literal["normal", "high"] | None = None
    assigned_to: str | None = None
    internal_note: str = Field(default="", max_length=5000)
    resolution: str = Field(default="", max_length=5000)
    note: str = Field(default="", max_length=1000)


class ConsultationHandleRequest(BaseModel):
    status: Literal["in_review", "waiting_for_user", "resolved", "closed"]
    internal_note: str = Field(default="", max_length=5000)
    resolution: str = Field(default="", max_length=5000)
    note: str = Field(default="", max_length=1000)


class ConsultationHistoryResponse(BaseModel):
    from_status: str | None
    to_status: str
    note: str
    created_at: datetime


class ConsultationResponse(BaseModel):
    id: str
    user_id: str
    source_message_id: str | None
    assigned_to: str | None
    subject: str
    description: str
    status: str
    priority: str
    resolution: str
    billing_type: str
    price: int
    created_at: datetime
    updated_at: datetime
    history: list[ConsultationHistoryResponse]


class ConsultationManagerResponse(ConsultationResponse):
    internal_note: str


class BookingCreateRequest(BaseModel):
    consultant_id: str
    scheduled_at: datetime
    mode: Literal["online", "in_person"] = "online"
    notes: str = Field(default="", max_length=1000)
