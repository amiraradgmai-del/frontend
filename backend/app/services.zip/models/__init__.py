from .auth import (
    AuditLog,
    FailedLoginAttempt,
    Permission,
    PendingRegistration,
    RefreshToken,
    Role,
    User,
    role_permissions,
    user_roles,
)
from .documents import (
    Document,
    DocumentChunk,
    DocumentProcessingJob,
    DocumentRelation,
    DocumentReview,
    DocumentTopic,
    DocumentVersion,
)
from .advisor import ChatMessage, Conversation, MessageCitation, MessageFeedback, RetrievalLog
from .consultations import ConsultationBooking, ConsultantProfile, ConsultationRequest, ConsultationStatusHistory
from .portal import DiscountCode, LawReferenceRecord, Payment, PaymentMethod, PaymentOtpChallenge, SubscriptionPlan, SupportTicket, TaxReminder, TicketMessage, ToolUsageEvent, UserDocument, UserProfile, UserSubscription, WalletAccount, WalletTransaction
from .site import SiteConfiguration, SiteConfigurationVersion

__all__ = [
    "AuditLog",
    "FailedLoginAttempt",
    "Permission",
    "PendingRegistration",
    "RefreshToken",
    "Role",
    "User",
    "role_permissions",
    "user_roles",
    "Document",
    "DocumentChunk",
    "DocumentProcessingJob",
    "DocumentRelation",
    "DocumentReview",
    "DocumentTopic",
    "DocumentVersion",
    "ChatMessage",
    "Conversation",
    "MessageCitation",
    "MessageFeedback",
    "RetrievalLog",
    "ConsultationRequest",
    "ConsultationStatusHistory",
    "ConsultantProfile",
    "ConsultationBooking",
    "UserProfile", "SubscriptionPlan", "UserSubscription", "PaymentMethod", "PaymentOtpChallenge",
    "Payment", "DiscountCode", "UserDocument", "SupportTicket", "TicketMessage", "TaxReminder", "ToolUsageEvent", "LawReferenceRecord", "WalletAccount", "WalletTransaction",
    "SiteConfiguration", "SiteConfigurationVersion",
]
