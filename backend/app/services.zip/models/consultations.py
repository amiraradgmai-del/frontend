from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, CheckConstraint, DateTime, Float, ForeignKey, Integer, JSON, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def new_uuid() -> str:
    return str(uuid.uuid4())


class ConsultationRequest(Base):
    __tablename__ = "consultation_requests"
    __table_args__ = (
        CheckConstraint(
            "status IN ('submitted','in_review','waiting_for_user','resolved','closed')",
            name="ck_consultation_requests_status",
        ),
        CheckConstraint(
            "priority IN ('normal','high')",
            name="ck_consultation_requests_priority",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    user_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    source_message_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("chat_messages.id", ondelete="SET NULL")
    )
    assigned_to: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="SET NULL"), index=True
    )
    subject: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(
        String(30), default="submitted", server_default="submitted"
    )
    priority: Mapped[str] = mapped_column(
        String(10), default="normal", server_default="normal"
    )
    internal_note: Mapped[str] = mapped_column(Text, default="")
    resolution: Mapped[str] = mapped_column(Text, default="")
    billing_type: Mapped[str] = mapped_column(String(20), default="free", server_default="free")
    price: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, onupdate=utc_now
    )

    history: Mapped[list[ConsultationStatusHistory]] = relationship(
        back_populates="consultation",
        cascade="all, delete-orphan",
        order_by="ConsultationStatusHistory.created_at",
    )


class ConsultationStatusHistory(Base):
    __tablename__ = "consultation_status_history"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    consultation_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("consultation_requests.id", ondelete="CASCADE"),
        index=True,
    )
    changed_by: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="RESTRICT")
    )
    from_status: Mapped[str | None] = mapped_column(String(30))
    to_status: Mapped[str] = mapped_column(String(30))
    note: Mapped[str] = mapped_column(String(1000), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    consultation: Mapped[ConsultationRequest] = relationship(back_populates="history")


class ConsultantProfile(Base):
    __tablename__ = "consultant_profiles"
    __table_args__ = (
        CheckConstraint("consultant_type IN ('independent','company')", name="ck_consultant_profiles_type"),
    )

    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    slug: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    consultant_type: Mapped[str] = mapped_column(String(20), index=True)
    professional_title: Mapped[str] = mapped_column(String(160))
    bio: Mapped[str] = mapped_column(Text)
    specialties: Mapped[list[str]] = mapped_column(JSON, default=list)
    years_experience: Mapped[int] = mapped_column(Integer, default=0)
    rating: Mapped[float] = mapped_column(Float, default=5.0)
    review_count: Mapped[int] = mapped_column(Integer, default=0)
    consultation_price: Mapped[int] = mapped_column(Integer, default=0)
    city: Mapped[str] = mapped_column(String(80), default="", server_default="")
    office_address: Mapped[str] = mapped_column(String(300), default="", server_default="")
    is_online: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    offers_in_person: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    is_available: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class ConsultationBooking(Base):
    __tablename__ = "consultation_bookings"
    __table_args__ = (
        UniqueConstraint("consultant_id", "scheduled_at", name="uq_consultation_booking_slot"),
        CheckConstraint("mode IN ('online','in_person','phone')", name="ck_consultation_bookings_mode"),
        CheckConstraint("status IN ('reserved','completed','cancelled')", name="ck_consultation_bookings_status"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    consultant_id: Mapped[str] = mapped_column(String(36), ForeignKey("consultant_profiles.user_id", ondelete="CASCADE"), index=True)
    scheduled_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    duration_minutes: Mapped[int] = mapped_column(Integer, default=30)
    mode: Mapped[str] = mapped_column(String(20), default="online")
    status: Mapped[str] = mapped_column(String(20), default="reserved", server_default="reserved")
    price: Mapped[int] = mapped_column(Integer, default=0)
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
