from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import JSON, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class SiteConfiguration(Base):
    __tablename__ = "site_configurations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    draft_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    published_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    published_version: Mapped[int] = mapped_column(Integer, default=1, server_default="1")
    updated_by: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="SET NULL")
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, onupdate=utc_now
    )


class SiteConfigurationVersion(Base):
    __tablename__ = "site_configuration_versions"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    version: Mapped[int] = mapped_column(Integer, index=True)
    configuration_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_by: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="SET NULL")
    )
    note: Mapped[str] = mapped_column(String(300), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
