from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.dependencies import get_session, require_permissions
from app.models.auth import AuditLog, User
from app.models.documents import Document, DocumentChunk, DocumentVersion
from app.models.portal import LawReferenceRecord
from app.models.site import SiteConfiguration, SiteConfigurationVersion
from app.schemas.site import SiteConfigPayload, SiteDraftUpdate, SitePublishRequest, SiteRollbackRequest

router = APIRouter(prefix="/api/v1/site", tags=["site configuration"])


def default_config() -> dict:
    return SiteConfigPayload().model_dump()


def get_configuration(session: Session) -> SiteConfiguration:
    item = session.get(SiteConfiguration, 1)
    if item is None:
        configuration = default_config()
        item = SiteConfiguration(id=1, draft_json=configuration, published_json=configuration)
        session.add(item)
        if session.scalar(select(SiteConfigurationVersion.id).where(SiteConfigurationVersion.version == 1)) is None:
            session.add(SiteConfigurationVersion(version=1, configuration_json=configuration, note="نسخه اولیه سامانه"))
        session.commit()
        session.refresh(item)
    return item


@router.get("/config")
def public_configuration(session: Annotated[Session, Depends(get_session)]):
    item = get_configuration(session)
    return {"version": item.published_version, "configuration": SiteConfigPayload.model_validate(item.published_json)}


@router.get("/manage")
def manage_configuration(
    request: Request,
    user: Annotated[User, Depends(require_permissions("site:manage"))],
    session: Annotated[Session, Depends(get_session)],
):
    del user
    item = get_configuration(session)
    settings = request.app.state.settings
    return {
        "published_version": item.published_version,
        "draft": SiteConfigPayload.model_validate(item.draft_json),
        "published": SiteConfigPayload.model_validate(item.published_json),
        "updated_at": item.updated_at,
        "services": {
            "environment": settings.environment,
            "ai_provider": "chaka_ai" if settings.gemini_api_key else "disabled",
            "ai_configured": bool(settings.gemini_api_key),
            "generation_model": "پاسخ هوشمند چکا",
            "embedding_model": "جست‌وجوی معنایی چکا",
            "email_mode": settings.email_delivery_mode,
            "storage_backend": settings.storage_backend,
        },
        "dataset": {
            "documents": session.scalar(select(func.count(Document.id))) or 0,
            "versions": session.scalar(select(func.count(DocumentVersion.id))) or 0,
            "chunks": session.scalar(select(func.count(DocumentChunk.id))) or 0,
            "starter_records": session.scalar(select(func.count(LawReferenceRecord.id))) or 0,
        },
    }


@router.patch("/manage/draft")
def update_draft(
    payload: SiteDraftUpdate,
    user: Annotated[User, Depends(require_permissions("site:manage"))],
    session: Annotated[Session, Depends(get_session)],
):
    item = get_configuration(session)
    item.draft_json = payload.configuration.model_dump()
    item.updated_by = user.id
    session.add(AuditLog(actor_user_id=user.id, action="site.draft_updated", resource_type="site_configuration", resource_id="1"))
    session.commit()
    return {"ok": True}


@router.post("/manage/publish")
def publish_configuration(
    payload: SitePublishRequest,
    user: Annotated[User, Depends(require_permissions("site:manage"))],
    session: Annotated[Session, Depends(get_session)],
):
    item = get_configuration(session)
    next_version = item.published_version + 1
    item.published_json = item.draft_json
    item.published_version = next_version
    item.updated_by = user.id
    session.add(SiteConfigurationVersion(version=next_version, configuration_json=item.published_json, created_by=user.id, note=payload.note))
    session.add(AuditLog(actor_user_id=user.id, action="site.published", resource_type="site_configuration", resource_id="1", metadata_json={"version": next_version}))
    session.commit()
    return {"ok": True, "version": next_version}


@router.get("/manage/versions")
def configuration_versions(
    user: Annotated[User, Depends(require_permissions("site:manage"))],
    session: Annotated[Session, Depends(get_session)],
):
    del user
    return [{"version": item.version, "note": item.note, "created_at": item.created_at} for item in session.scalars(select(SiteConfigurationVersion).order_by(SiteConfigurationVersion.version.desc()).limit(30))]


@router.post("/manage/rollback")
def rollback_configuration(
    payload: SiteRollbackRequest,
    user: Annotated[User, Depends(require_permissions("site:manage"))],
    session: Annotated[Session, Depends(get_session)],
):
    previous = session.scalar(select(SiteConfigurationVersion).where(SiteConfigurationVersion.version == payload.version))
    if previous is None:
        raise HTTPException(404, "Configuration version not found")
    item = get_configuration(session)
    next_version = item.published_version + 1
    item.draft_json = previous.configuration_json
    item.published_json = previous.configuration_json
    item.published_version = next_version
    item.updated_by = user.id
    session.add(SiteConfigurationVersion(version=next_version, configuration_json=previous.configuration_json, created_by=user.id, note=payload.note))
    session.add(AuditLog(actor_user_id=user.id, action="site.rolled_back", resource_type="site_configuration", resource_id="1", metadata_json={"source_version": payload.version, "version": next_version}))
    session.commit()
    return {"ok": True, "version": next_version}
