from typing import Annotated

import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.dependencies import get_consultation_service, get_current_user, get_session, require_permissions
from app.models.auth import Role, User
from app.models.consultations import ConsultationBooking, ConsultantProfile, ConsultationRequest
from app.models.portal import WalletAccount, WalletTransaction
from app.schemas.consultations import BookingCreateRequest, ConsultationCreateRequest, ConsultationHandleRequest, ConsultationManagerResponse, ConsultationResponse, ConsultationUpdateRequest
from app.services.plans import scaled_limits
from app.services.consultations import ConsultationNotFoundError, ConsultationService, InvalidConsultationError
from app.services.site import feature_enabled

router = APIRouter(prefix="/api/v1/consultations", tags=["consultations"])


@router.post("", response_model=ConsultationResponse, status_code=status.HTTP_201_CREATED)
def create(payload: ConsultationCreateRequest, user: Annotated[User, Depends(get_current_user)], service: Annotated[ConsultationService, Depends(get_consultation_service)], session: Annotated[Session, Depends(get_session)]):
    if not feature_enabled(session, "consultations_enabled"):
        raise HTTPException(status_code=503, detail="Consultations are disabled")
    try:
        return service.create(subject=payload.subject, description=payload.description, source_message_id=payload.source_message_id, use_wallet_if_needed=payload.use_wallet_if_needed, user=user)
    except InvalidConsultationError as error:
        raise HTTPException(status_code=422, detail=str(error)) from None


@router.get("", response_model=list[ConsultationResponse])
def mine(user: Annotated[User, Depends(get_current_user)], service: Annotated[ConsultationService, Depends(get_consultation_service)]):
    return service.list_for_user(user)


def profile_data(profile: ConsultantProfile, user: User) -> dict:
    return {"id": profile.user_id, "slug": profile.slug, "full_name": user.full_name, "consultant_type": profile.consultant_type, "professional_title": profile.professional_title, "bio": profile.bio, "specialties": profile.specialties, "years_experience": profile.years_experience, "rating": profile.rating, "review_count": profile.review_count, "consultation_price": profile.consultation_price, "city": profile.city, "office_address": profile.office_address, "is_online": profile.is_online, "offers_in_person": profile.offers_in_person, "is_verified": profile.is_verified, "is_available": profile.is_available}


@router.get("/advisors")
def advisors(session: Annotated[Session, Depends(get_session)], user: Annotated[User, Depends(get_current_user)], consultant_type: Annotated[str, Query(alias="type")] = "independent"):
    del user
    rows = session.execute(select(ConsultantProfile, User).join(User, User.id == ConsultantProfile.user_id).where(ConsultantProfile.consultant_type == consultant_type, ConsultantProfile.is_verified.is_(True), ConsultantProfile.is_available.is_(True)).order_by(ConsultantProfile.rating.desc(), User.full_name))
    return [profile_data(profile, account) for profile, account in rows]


@router.get("/advisors/{slug}")
def advisor(slug: str, session: Annotated[Session, Depends(get_session)], user: Annotated[User, Depends(get_current_user)]):
    del user
    row = session.execute(select(ConsultantProfile, User).join(User, User.id == ConsultantProfile.user_id).where(ConsultantProfile.slug == slug, ConsultantProfile.is_verified.is_(True))).first()
    if row is None: raise HTTPException(404, "مشاور پیدا نشد")
    result = profile_data(row[0], row[1])
    booked = set(session.scalars(select(ConsultationBooking.scheduled_at).where(ConsultationBooking.consultant_id == row[0].user_id, ConsultationBooking.status == "reserved", ConsultationBooking.scheduled_at >= datetime.now(timezone.utc))).all())
    slots = []
    for day in range(1, 8):
        date = (datetime.now(timezone.utc) + timedelta(days=day)).replace(minute=0, second=0, microsecond=0)
        for hour in (9, 11, 14, 16):
            slot = date.replace(hour=hour)
            if slot not in booked: slots.append(slot)
    result["available_slots"] = slots
    return result


@router.get("/company/quota")
def company_quota(user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    month_start = datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    limits = {"normal": {"consultations": 1}, "plus": {"consultations": 2}, "pro": {"consultations": 10}}
    limit = scaled_limits(session, user, limits)["consultations"]
    used = session.scalar(select(func.count(ConsultationRequest.id)).where(ConsultationRequest.user_id == user.id, ConsultationRequest.created_at >= month_start)) or 0
    wallet = session.get(WalletAccount, user.id)
    return {"free_limit": limit, "used": min(used, limit), "remaining": max(0, limit - used), "next_price": 149000, "wallet_balance": wallet.balance if wallet else 0}


@router.get("/bookings/mine")
def my_bookings(user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    rows = session.execute(select(ConsultationBooking, ConsultantProfile, User).join(ConsultantProfile, ConsultantProfile.user_id == ConsultationBooking.consultant_id).join(User, User.id == ConsultantProfile.user_id).where(ConsultationBooking.user_id == user.id).order_by(ConsultationBooking.scheduled_at.desc()))
    return [{"id": booking.id, "consultant_name": account.full_name, "slug": profile.slug, "scheduled_at": booking.scheduled_at, "mode": booking.mode, "status": booking.status, "price": booking.price} for booking, profile, account in rows]


@router.post("/bookings", status_code=201)
def create_booking(payload: BookingCreateRequest, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    if user.account_tier == "normal":
        raise HTTPException(403, "رزرو مشاور مستقل فقط برای کاربران دارای اشتراک پلاس یا حرفه‌ای فعال است.")
    profile = session.get(ConsultantProfile, payload.consultant_id)
    if profile is not None and payload.mode == "online" and not profile.is_online:
        raise HTTPException(422, "این مشاور، مشاوره آنلاین ارائه نمی‌دهد.")
    if profile is not None and payload.mode == "in_person" and not profile.offers_in_person:
        raise HTTPException(422, "این مشاور، مشاوره حضوری ارائه نمی‌دهد.")
    if profile is None or profile.consultant_type != "independent" or not profile.is_available: raise HTTPException(404, "مشاور در دسترس نیست")
    scheduled_at = payload.scheduled_at if payload.scheduled_at.tzinfo else payload.scheduled_at.replace(tzinfo=timezone.utc)
    if scheduled_at <= datetime.now(timezone.utc): raise HTTPException(422, "زمان رزرو معتبر نیست")
    wallet = session.get(WalletAccount, user.id)
    if wallet is None or wallet.balance < profile.consultation_price: raise HTTPException(422, "موجودی کیف پول برای رزرو کافی نیست")
    wallet.balance -= profile.consultation_price
    booking_id = str(uuid.uuid4())
    booking = ConsultationBooking(id=booking_id, user_id=user.id, consultant_id=profile.user_id, scheduled_at=scheduled_at, duration_minutes=30, mode=payload.mode, price=profile.consultation_price, notes=payload.notes.strip())
    session.add(booking)
    session.add(WalletTransaction(user_id=user.id, transaction_type="consultation", amount=profile.consultation_price, status="completed", reference=f"BOOK-{booking_id[:12].upper()}", otp_hash="", otp_expires_at=datetime.now(timezone.utc)))
    try: session.commit()
    except IntegrityError: session.rollback(); raise HTTPException(409, "این زمان قبلاً رزرو شده است") from None
    return {"id": booking.id, "status": booking.status, "scheduled_at": booking.scheduled_at, "price": booking.price}


@router.get("/manage/all", response_model=list[ConsultationManagerResponse])
def manage_all(user: Annotated[User, Depends(require_permissions("consultations:manage"))], service: Annotated[ConsultationService, Depends(get_consultation_service)], request_status: Annotated[str | None, Query(alias="status")] = None):
    del user
    return service.list_all(request_status)


@router.get("/manage/consultants")
def consultants(
    user: Annotated[User, Depends(require_permissions("consultations:manage"))],
    session: Annotated[Session, Depends(get_session)],
):
    del user
    rows = session.execute(
        select(User.id, User.full_name, User.email).distinct()
        .join(User.roles)
        .where(Role.name.in_(("company_expert", "tax_expert", "consultant")), User.is_active.is_(True))
        .order_by(User.full_name)
    )
    return [{"id": user_id, "full_name": full_name, "email": email} for user_id, full_name, email in rows]


@router.patch("/manage/{consultation_id}", response_model=ConsultationManagerResponse)
def manage_update(consultation_id: str, payload: ConsultationUpdateRequest, user: Annotated[User, Depends(require_permissions("consultations:manage"))], service: Annotated[ConsultationService, Depends(get_consultation_service)]):
    try:
        return service.update(consultation_id, status=payload.status, priority=payload.priority, assigned_to=payload.assigned_to, internal_note=payload.internal_note, resolution=payload.resolution, note=payload.note, user=user)
    except ConsultationNotFoundError:
        raise HTTPException(status_code=404, detail="Consultation not found") from None
    except InvalidConsultationError as error:
        raise HTTPException(status_code=422, detail=str(error)) from None


@router.get("/assigned/me", response_model=list[ConsultationManagerResponse])
def assigned_to_me(
    user: Annotated[User, Depends(require_permissions("consultations:handle"))],
    service: Annotated[ConsultationService, Depends(get_consultation_service)],
):
    return service.list_assigned(user)


@router.patch("/assigned/{consultation_id}", response_model=ConsultationManagerResponse)
def handle_assigned(
    consultation_id: str,
    payload: ConsultationHandleRequest,
    user: Annotated[User, Depends(require_permissions("consultations:handle"))],
    service: Annotated[ConsultationService, Depends(get_consultation_service)],
):
    try:
        return service.handle_assigned(
            consultation_id,
            status=payload.status,
            internal_note=payload.internal_note,
            resolution=payload.resolution,
            note=payload.note,
            user=user,
        )
    except ConsultationNotFoundError:
        raise HTTPException(status_code=404, detail="Consultation not found") from None
    except InvalidConsultationError as error:
        raise HTTPException(status_code=422, detail=str(error)) from None


@router.get("/{consultation_id}", response_model=ConsultationResponse)
def get_one(consultation_id: str, user: Annotated[User, Depends(get_current_user)], service: Annotated[ConsultationService, Depends(get_consultation_service)]):
    try:
        return service.get_for_user(consultation_id, user)
    except ConsultationNotFoundError:
        raise HTTPException(status_code=404, detail="Consultation not found") from None
