from __future__ import annotations

import hashlib
import hmac
import re
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.api.dependencies import get_current_user, get_session, require_permissions
from app.documents.storage import ObjectStorage
from app.documents.validation import FileValidationError, validate_upload
from app.models.advisor import ChatMessage, Conversation
from app.models.auth import User
from app.models.portal import DiscountCode, Payment, PaymentMethod, PaymentOtpChallenge, SubscriptionPlan, SupportTicket, TicketMessage, UserDocument, UserProfile, UserSubscription, WalletAccount, WalletTransaction
from app.services.plans import package_price, scaled_limits

router = APIRouter(prefix="/api/v1/portal", tags=["customer portal"])
admin_router = APIRouter(prefix="/api/v1/admin", tags=["admin portal"])


class ProfileUpdate(BaseModel):
    phone: str = Field(default="", max_length=20)
    province: str = Field(default="", max_length=80)
    city: str = Field(default="", max_length=80)
    company_name: str = Field(default="", max_length=160)
    job_title: str = Field(default="", max_length=100)
    taxpayer_type: str = Field(default="individual", max_length=30)
    bio: str = Field(default="", max_length=1000)


class CardCreate(BaseModel):
    card_number: str = Field(min_length=16, max_length=25)
    cardholder_name: str = Field(min_length=2, max_length=120)


class CheckoutRequest(BaseModel):
    plan_code: str
    package: Literal["silver", "gold", "diamond"] = "silver"
    payment_method_id: str | None = None
    discount_code: str = Field(default="", max_length=32)
    otp_request_id: str | None = None
    otp_code: str = Field(default="", max_length=6, pattern="^$|^[0-9]{6}$")


class WalletRequest(BaseModel):
    transaction_type: Literal["charge", "withdraw"]
    amount: int = Field(ge=10_000, le=100_000_000)


class WalletConfirm(BaseModel):
    transaction_id: str
    code: str = Field(pattern="^[0-9]{6}$")


class TicketCreate(BaseModel):
    subject: str = Field(min_length=3, max_length=200)
    category: str = Field(default="general", max_length=40)
    message: str = Field(min_length=5, max_length=5000)


class MessageCreate(BaseModel):
    message: str = Field(min_length=1, max_length=5000)


class DocumentAdminUpdate(BaseModel):
    status: str = Field(pattern="^(uploaded|reviewing|accepted|rejected)$")
    admin_note: str = Field(default="", max_length=2000)


class DiscountCreate(BaseModel):
    code: str = Field(min_length=3, max_length=32, pattern="^[A-Za-z0-9_-]+$")
    percent: int = Field(ge=1, le=100)
    max_uses: int = Field(default=100, ge=1, le=100000)
    is_active: bool = True


class DiscountUpdate(BaseModel):
    percent: int | None = Field(default=None, ge=1, le=100)
    max_uses: int | None = Field(default=None, ge=1, le=100000)
    is_active: bool | None = None


class SubscriptionAdminUpdate(BaseModel):
    status: str = Field(pattern="^(active|cancelled)$")


class TicketAdminUpdate(BaseModel):
    status: str = Field(pattern="^(open|answered|closed)$")


PLAN_LIMITS = {
    "normal": {"documents": 1, "tickets": 1},
    "plus": {"documents": 5, "tickets": 5},
    "pro": {"documents": 20, "tickets": 20},
}


def profile_for(session: Session, user: User) -> UserProfile:
    profile = session.get(UserProfile, user.id)
    if profile is None:
        profile = UserProfile(user_id=user.id, referral_code=user.id.replace("-", "")[:10].upper())
        session.add(profile); session.commit(); session.refresh(profile)
    return profile


def profile_data(profile: UserProfile) -> dict:
    return {"phone":profile.phone,"province":profile.province,"city":profile.city,"company_name":profile.company_name,"job_title":profile.job_title,"taxpayer_type":profile.taxpayer_type,"bio":profile.bio,"profile_score":profile.profile_score,"reward_points":profile.reward_points,"referral_code":profile.referral_code}


def plan_data(plan: SubscriptionPlan) -> dict:
    return {"id":plan.id,"code":plan.code,"title":plan.title,"description":plan.description,"price":plan.price,"duration_days":plan.duration_days,"benefits":plan.benefits,"is_active":plan.is_active}


def ticket_data(ticket: SupportTicket) -> dict:
    return {"id":ticket.id,"user_id":ticket.user_id,"subject":ticket.subject,"category":ticket.category,"priority":ticket.priority,"status":ticket.status,"created_at":ticket.created_at,"updated_at":ticket.updated_at,"messages":[{"id":m.id,"message":m.message,"is_staff":m.is_staff,"created_at":m.created_at} for m in ticket.messages]}


@router.get("/overview")
def overview(user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    profile = profile_for(session, user)
    subscription = session.scalar(select(UserSubscription).where(UserSubscription.user_id == user.id, UserSubscription.status == "active").order_by(UserSubscription.ends_at.desc()))
    remaining_percent = None
    if subscription:
        starts_at = subscription.starts_at.replace(tzinfo=timezone.utc) if subscription.starts_at.tzinfo is None else subscription.starts_at
        ends_at = subscription.ends_at.replace(tzinfo=timezone.utc) if subscription.ends_at.tzinfo is None else subscription.ends_at
        total_seconds = max(1, (ends_at - starts_at).total_seconds())
        remaining_percent = max(0, min(100, round((ends_at - datetime.now(timezone.utc)).total_seconds() / total_seconds * 100)))
    return {"profile":profile_data(profile),"subscription":({"plan":plan_data(subscription.plan),"package":subscription.package_code,"starts_at":subscription.starts_at,"ends_at":subscription.ends_at,"remaining_percent":remaining_percent,"auto_renew":subscription.auto_renew} if subscription else None),"documents":session.scalar(select(func.count(UserDocument.id)).where(UserDocument.user_id==user.id)) or 0,"tickets":session.scalar(select(func.count(SupportTicket.id)).where(SupportTicket.user_id==user.id,SupportTicket.status!="closed")) or 0,"chats":session.scalar(select(func.count(Conversation.id)).where(Conversation.user_id==user.id,Conversation.deleted_at.is_(None))) or 0}


@router.get("/profile")
def get_profile(user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]): return profile_data(profile_for(session,user))


@router.patch("/profile")
def update_profile(payload: ProfileUpdate, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    profile=profile_for(session,user)
    for key,value in payload.model_dump().items(): setattr(profile,key,value.strip() if isinstance(value,str) else value)
    completed=sum(bool(getattr(profile,key)) for key in ["phone","province","city","company_name","job_title","bio"])
    profile.profile_score=min(100,10+completed*15)
    if profile.profile_score == 100 and not profile.completion_rewarded:
        profile.reward_points += 500
        profile.completion_rewarded = True
    session.commit(); return profile_data(profile)


@router.get("/plans")
def plans(session: Annotated[Session, Depends(get_session)], user: Annotated[User, Depends(get_current_user)]):
    del user; return [plan_data(item) for item in session.scalars(select(SubscriptionPlan).where(SubscriptionPlan.is_active.is_(True)).order_by(SubscriptionPlan.sort_order))]


def luhn(number: str) -> bool:
    total=0
    for index,digit in enumerate(reversed(number)):
        value=int(digit)*(2 if index%2 else 1); total += value-9 if value>9 else value
    return total%10==0


@router.get("/payment-methods")
def payment_methods(user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    return [{"id":m.id,"cardholder_name":m.cardholder_name,"last_four":m.last_four,"issuer":m.issuer,"is_default":m.is_default} for m in session.scalars(select(PaymentMethod).where(PaymentMethod.user_id==user.id).order_by(PaymentMethod.created_at.desc()))]


@router.patch("/payment-methods/{method_id}/default")
def set_default_card(method_id: str, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    method = session.scalar(select(PaymentMethod).where(PaymentMethod.id == method_id, PaymentMethod.user_id == user.id))
    if method is None: raise HTTPException(404, "کارت پیدا نشد")
    session.query(PaymentMethod).filter(PaymentMethod.user_id == user.id).update({"is_default": False})
    method.is_default = True; session.commit(); return {"ok": True}


@router.delete("/payment-methods/{method_id}", status_code=204)
def delete_card(method_id: str, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    method = session.scalar(select(PaymentMethod).where(PaymentMethod.id == method_id, PaymentMethod.user_id == user.id))
    if method is None: raise HTTPException(404, "کارت پیدا نشد")
    if session.scalar(select(Payment.id).where(Payment.payment_method_id == method.id)):
        raise HTTPException(409, "کارت دارای سابقه پرداخت است و قابل حذف نیست")
    session.delete(method); session.commit()


@router.post("/checkout/preview")
def checkout_preview(payload: CheckoutRequest, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    del user
    plan = session.scalar(select(SubscriptionPlan).where(SubscriptionPlan.code == payload.plan_code, SubscriptionPlan.is_active.is_(True)))
    if plan is None: raise HTTPException(404, "پلن پیدا نشد")
    amount = package_price(plan.price, payload.package)
    discount_amount = 0
    if payload.discount_code.strip():
        discount = session.scalar(select(DiscountCode).where(DiscountCode.code == payload.discount_code.strip().upper(), DiscountCode.is_active.is_(True)))
        if discount is None or discount.used_count >= discount.max_uses: raise HTTPException(422, "کد تخفیف معتبر نیست")
        discount_amount = amount * discount.percent // 100
    return {"amount": amount, "discount_amount": discount_amount, "payable": amount - discount_amount}


def wallet_for(session: Session, user: User) -> WalletAccount:
    wallet = session.get(WalletAccount, user.id)
    if wallet is None:
        wallet = WalletAccount(user_id=user.id)
        session.add(wallet); session.commit(); session.refresh(wallet)
    return wallet


@router.get("/wallet")
def wallet(user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    account = wallet_for(session, user)
    profile = profile_for(session, user)
    items = session.scalars(select(WalletTransaction).where(WalletTransaction.user_id == user.id).order_by(WalletTransaction.created_at.desc()).limit(50)).all()
    return {"balance": account.balance, "points": profile.reward_points, "referral_code": profile.referral_code, "transactions": [{"id": item.id, "type": item.transaction_type, "amount": item.amount, "status": item.status, "reference": item.reference, "created_at": item.created_at} for item in items]}


@router.post("/wallet/otp", status_code=201)
def wallet_otp(payload: WalletRequest, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    account = wallet_for(session, user)
    if payload.transaction_type == "withdraw":
        if payload.amount > account.balance: raise HTTPException(422, "موجودی کیف پول کافی نیست")
        day_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        withdrawn = session.scalar(select(func.sum(WalletTransaction.amount)).where(WalletTransaction.user_id == user.id, WalletTransaction.transaction_type == "withdraw", WalletTransaction.status.in_(["pending", "completed"]), WalletTransaction.created_at >= day_start)) or 0
        if withdrawn + payload.amount > 10_000_000: raise HTTPException(422, "سقف برداشت روزانه ۱۰ میلیون تومان است")
    code = f"{secrets.randbelow(900000) + 100000}"
    item = WalletTransaction(user_id=user.id, transaction_type=payload.transaction_type, amount=payload.amount, status="otp_pending", reference=f"WALLET-{uuid.uuid4().hex[:12].upper()}", otp_hash="", otp_expires_at=datetime.now(timezone.utc) + timedelta(minutes=2))
    session.add(item); session.flush(); item.otp_hash = hashlib.sha256(f"{item.id}:{code}".encode()).hexdigest(); session.commit()
    return {"transaction_id": item.id, "expires_in": 120, "test_otp": code}


@router.post("/wallet/confirm")
def wallet_confirm(payload: WalletConfirm, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    item = session.scalar(select(WalletTransaction).where(WalletTransaction.id == payload.transaction_id, WalletTransaction.user_id == user.id))
    if item is None or item.status != "otp_pending": raise HTTPException(422, "درخواست کیف پول معتبر نیست")
    expires_at = item.otp_expires_at if item.otp_expires_at.tzinfo else item.otp_expires_at.replace(tzinfo=timezone.utc)
    if expires_at < datetime.now(timezone.utc): raise HTTPException(422, "کد تأیید منقضی شده است")
    expected = hashlib.sha256(f"{item.id}:{payload.code}".encode()).hexdigest()
    if not hmac.compare_digest(item.otp_hash, expected): raise HTTPException(422, "کد تأیید صحیح نیست")
    account = wallet_for(session, user)
    if item.transaction_type == "charge":
        account.balance += item.amount; item.status = "completed"
    else:
        if item.amount > account.balance: raise HTTPException(422, "موجودی کیف پول کافی نیست")
        account.balance -= item.amount; item.status = "pending"
    session.commit(); return {"balance": account.balance, "status": item.status}


@router.post("/payment-methods", status_code=201)
def add_card(payload: CardCreate, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    number=re.sub(r"\D","",payload.card_number)
    if len(number)!=16 or not luhn(number): raise HTTPException(422,"شماره کارت معتبر نیست")
    fingerprint=hashlib.sha256(f"{user.id}:{number}".encode()).hexdigest()
    existing=session.scalar(select(PaymentMethod).where(PaymentMethod.fingerprint==fingerprint))
    if existing: return {"id":existing.id,"last_four":existing.last_four,"issuer":existing.issuer}
    session.query(PaymentMethod).filter(PaymentMethod.user_id==user.id).update({"is_default":False})
    item=PaymentMethod(user_id=user.id,cardholder_name=payload.cardholder_name,last_four=number[-4:],fingerprint=fingerprint,is_default=True)
    session.add(item); session.commit(); return {"id":item.id,"last_four":item.last_four,"issuer":item.issuer}


@router.post("/checkout", status_code=201)
def checkout(payload: CheckoutRequest, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    plan=session.scalar(select(SubscriptionPlan).where(SubscriptionPlan.code==payload.plan_code,SubscriptionPlan.is_active.is_(True)))
    if plan is None: raise HTTPException(404,"پلن پیدا نشد")
    method=None
    if plan.price>0:
        method=session.scalar(select(PaymentMethod).where(PaymentMethod.id==payload.payment_method_id,PaymentMethod.user_id==user.id))
        if method is None: raise HTTPException(422,"ابتدا یک کارت بانکی معتبر ثبت کنید")
        challenge=session.scalar(select(PaymentOtpChallenge).where(PaymentOtpChallenge.id==payload.otp_request_id,PaymentOtpChallenge.user_id==user.id))
        if challenge is None or challenge.used_at is not None: raise HTTPException(422,"درخواست رمز پویا معتبر نیست")
        expires_at=challenge.expires_at if challenge.expires_at.tzinfo else challenge.expires_at.replace(tzinfo=timezone.utc)
        if expires_at<datetime.now(timezone.utc): raise HTTPException(422,"رمز پویا منقضی شده است؛ رمز جدید بگیرید")
        if challenge.attempts>=5: raise HTTPException(429,"تعداد تلاش مجاز تمام شده است؛ رمز جدید بگیرید")
        if challenge.plan_code!=f"{payload.plan_code}:{payload.package}" or challenge.payment_method_id!=payload.payment_method_id or challenge.discount_code!=payload.discount_code.strip().upper(): raise HTTPException(422,"اطلاعات پرداخت پس از دریافت رمز تغییر کرده است")
        expected=hashlib.sha256(f"{challenge.id}:{payload.otp_code}".encode()).hexdigest()
        if not hmac.compare_digest(challenge.otp_hash,expected):
            challenge.attempts+=1; session.commit(); raise HTTPException(422,"رمز پویا صحیح نیست")
        challenge.used_at=datetime.now(timezone.utc)
    amount = package_price(plan.price, payload.package)
    discount=None; discount_amount=0; now=datetime.now(timezone.utc)
    if payload.discount_code.strip():
        discount=session.scalar(select(DiscountCode).where(DiscountCode.code==payload.discount_code.strip().upper(),DiscountCode.is_active.is_(True)))
        if discount is None or discount.used_count>=discount.max_uses or (discount.expires_at and discount.expires_at<now): raise HTTPException(422,"کد تخفیف معتبر نیست")
        discount_amount=amount*discount.percent//100; discount.used_count+=1
    payment=Payment(user_id=user.id,plan_id=plan.id,payment_method_id=method.id if method else None,discount_code_id=discount.id if discount else None,amount=amount-discount_amount,discount_amount=discount_amount,status="paid",gateway_reference=f"SANDBOX-{uuid.uuid4().hex[:16].upper()}",paid_at=now)
    session.query(UserSubscription).filter(UserSubscription.user_id==user.id,UserSubscription.status=="active").update({"status":"replaced"})
    subscription=UserSubscription(user_id=user.id,plan_id=plan.id,status="active",package_code=payload.package,starts_at=now,ends_at=now+timedelta(days=plan.duration_days))
    user.account_tier=plan.code; session.add_all([payment,subscription]); session.commit()
    return {"payment_id":payment.id,"status":payment.status,"amount":payment.amount,"discount_amount":discount_amount,"reference":payment.gateway_reference,"package":payload.package,"plan":plan_data(plan)}


@router.post("/payment-otp", status_code=201)
def request_payment_otp(payload: CheckoutRequest, request: Request, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    plan=session.scalar(select(SubscriptionPlan).where(SubscriptionPlan.code==payload.plan_code,SubscriptionPlan.is_active.is_(True)))
    if plan is None or plan.price<=0: raise HTTPException(422,"این پلن به رمز پویا نیاز ندارد")
    method=session.scalar(select(PaymentMethod).where(PaymentMethod.id==payload.payment_method_id,PaymentMethod.user_id==user.id))
    if method is None: raise HTTPException(422,"ابتدا یک کارت بانکی معتبر ثبت کنید")
    code=f"{secrets.randbelow(900000)+100000}"
    challenge=PaymentOtpChallenge(user_id=user.id,plan_code=f"{plan.code}:{payload.package}",payment_method_id=method.id,discount_code=payload.discount_code.strip().upper(),otp_hash="",expires_at=datetime.now(timezone.utc)+timedelta(minutes=2))
    session.add(challenge); session.flush()
    challenge.otp_hash=hashlib.sha256(f"{challenge.id}:{code}".encode()).hexdigest()
    session.commit()
    response={"request_id":challenge.id,"expires_in":120,"card_last_four":method.last_four}
    response["test_otp"] = code
    return response


@router.get("/payments")
def my_payments(user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]):
    return [{"id":p.id,"plan":p.plan.title,"amount":p.amount,"discount_amount":p.discount_amount,"status":p.status,"reference":p.gateway_reference,"created_at":p.created_at} for p in session.scalars(select(Payment).where(Payment.user_id==user.id).order_by(Payment.created_at.desc()))]


@router.get("/documents")
def my_documents(user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]): return [{"id":d.id,"title":d.title,"filename":d.original_filename,"file_size":d.file_size,"status":d.status,"admin_note":d.admin_note,"created_at":d.created_at} for d in session.scalars(select(UserDocument).where(UserDocument.user_id==user.id).order_by(UserDocument.created_at.desc()))]


@router.post("/documents", status_code=201)
async def upload_document(request: Request, user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)], title: Annotated[str, Form()], file: Annotated[UploadFile, File()]):
    limit = scaled_limits(session, user, PLAN_LIMITS)["documents"]
    used = session.scalar(select(func.count(UserDocument.id)).where(UserDocument.user_id == user.id)) or 0
    if used >= limit:
        raise HTTPException(429, f"سقف {limit} سند در پلن شما تکمیل شده است؛ برای افزایش ظرفیت پلن را ارتقا دهید.")
    data=await file.read(20*1024*1024+1)
    try: validated=validate_upload(file.filename or "",file.content_type,data,20*1024*1024)
    except FileValidationError as error: raise HTTPException(422,str(error)) from None
    storage: ObjectStorage = request.app.state.storage
    key=f"user-documents/{user.id}/{uuid.uuid4().hex}{validated.extension}"
    storage.put(key,validated.data,validated.mime_type)
    item=UserDocument(user_id=user.id,title=title.strip(),original_filename=validated.filename,storage_key=key,mime_type=validated.mime_type,file_size=len(validated.data))
    session.add(item); session.commit()
    return {"id":item.id,"title":item.title,"filename":item.original_filename,"file_size":item.file_size,"status":item.status,"created_at":item.created_at}


@router.get("/tickets")
def my_tickets(user: Annotated[User, Depends(get_current_user)], session: Annotated[Session, Depends(get_session)]): return [ticket_data(t) for t in session.scalars(select(SupportTicket).where(SupportTicket.user_id==user.id).options(selectinload(SupportTicket.messages)).order_by(SupportTicket.updated_at.desc()))]


@router.post("/tickets", status_code=201)
def create_ticket(payload: TicketCreate,user: Annotated[User, Depends(get_current_user)],session: Annotated[Session, Depends(get_session)]):
    limit = scaled_limits(session, user, PLAN_LIMITS)["tickets"]
    active = session.scalar(select(func.count(SupportTicket.id)).where(SupportTicket.user_id == user.id, SupportTicket.status != "closed")) or 0
    if active >= limit:
        raise HTTPException(429, f"سقف {limit} تیکت فعال در پلن شما تکمیل شده است.")
    ticket=SupportTicket(user_id=user.id,subject=payload.subject,category=payload.category); session.add(ticket); session.flush(); session.add(TicketMessage(ticket_id=ticket.id,sender_user_id=user.id,message=payload.message,is_staff=False)); session.commit(); return ticket_data(session.scalar(select(SupportTicket).where(SupportTicket.id==ticket.id).options(selectinload(SupportTicket.messages))))


@router.post("/tickets/{ticket_id}/messages")
def reply_ticket(ticket_id:str,payload:MessageCreate,user:Annotated[User,Depends(get_current_user)],session:Annotated[Session,Depends(get_session)]):
    ticket=session.scalar(select(SupportTicket).where(SupportTicket.id==ticket_id,SupportTicket.user_id==user.id));
    if ticket is None: raise HTTPException(404,"تیکت پیدا نشد")
    if ticket.status=="closed": raise HTTPException(409,"تیکت بسته شده است")
    if ticket.status!="answered": raise HTTPException(409,"تا زمان پاسخ پشتیبانی امکان ارسال پیام جدید وجود ندارد")
    session.add(TicketMessage(ticket_id=ticket.id,sender_user_id=user.id,message=payload.message,is_staff=False)); ticket.status="open"; session.commit(); return {"ok":True}


@admin_router.get("/summary")
def admin_summary(user:Annotated[User,Depends(require_permissions("users:manage"))],session:Annotated[Session,Depends(get_session)]):
    del user; return {"users":session.scalar(select(func.count(User.id))) or 0,"payments":session.scalar(select(func.count(Payment.id))) or 0,"revenue":session.scalar(select(func.sum(Payment.amount)).where(Payment.status=="paid")) or 0,"active_subscriptions":session.scalar(select(func.count(UserSubscription.id)).where(UserSubscription.status=="active")) or 0,"open_tickets":session.scalar(select(func.count(SupportTicket.id)).where(SupportTicket.status!="closed")) or 0,"user_documents":session.scalar(select(func.count(UserDocument.id))) or 0,"conversations":session.scalar(select(func.count(Conversation.id)).where(Conversation.deleted_at.is_(None))) or 0}


@admin_router.get("/payments")
def admin_payments(user:Annotated[User,Depends(require_permissions("payments:manage"))],session:Annotated[Session,Depends(get_session)]):
    del user; rows=session.execute(select(Payment,User.email).join(User,User.id==Payment.user_id).order_by(Payment.created_at.desc())); return [{"id":p.id,"email":email,"plan":p.plan.title,"amount":p.amount,"discount_amount":p.discount_amount,"status":p.status,"reference":p.gateway_reference,"created_at":p.created_at} for p,email in rows]


@admin_router.get("/subscriptions")
def admin_subscriptions(user:Annotated[User,Depends(require_permissions("subscriptions:manage"))],session:Annotated[Session,Depends(get_session)]):
    del user; rows=session.execute(select(UserSubscription,User.email).join(User,User.id==UserSubscription.user_id).order_by(UserSubscription.created_at.desc())); return [{"id":s.id,"email":email,"plan":s.plan.title,"package":s.package_code,"status":s.status,"starts_at":s.starts_at,"ends_at":s.ends_at} for s,email in rows]


@admin_router.patch("/subscriptions/{subscription_id}")
def update_subscription(subscription_id: str, payload: SubscriptionAdminUpdate, user: Annotated[User, Depends(require_permissions("subscriptions:manage"))], session: Annotated[Session, Depends(get_session)]):
    del user
    item = session.get(UserSubscription, subscription_id)
    if item is None:
        raise HTTPException(404, "اشتراک پیدا نشد")
    if payload.status == "active":
        session.query(UserSubscription).filter(UserSubscription.user_id == item.user_id, UserSubscription.id != item.id, UserSubscription.status == "active").update({"status": "replaced"})
        item.status = "active"
        item.ends_at = datetime.now(timezone.utc) + timedelta(days=30)
        session.get(User, item.user_id).account_tier = item.plan.code
    else:
        item.status = "cancelled"
        session.get(User, item.user_id).account_tier = "normal"
    session.commit()
    return {"ok": True}


@admin_router.get("/user-documents")
def admin_documents(user:Annotated[User,Depends(require_permissions("user_documents:manage"))],session:Annotated[Session,Depends(get_session)]):
    del user; rows=session.execute(select(UserDocument,User.email).join(User,User.id==UserDocument.user_id).order_by(UserDocument.created_at.desc())); return [{"id":d.id,"email":email,"title":d.title,"filename":d.original_filename,"file_size":d.file_size,"status":d.status,"admin_note":d.admin_note,"created_at":d.created_at} for d,email in rows]


@admin_router.patch("/user-documents/{document_id}")
def review_user_document(document_id:str,payload:DocumentAdminUpdate,user:Annotated[User,Depends(require_permissions("user_documents:manage"))],session:Annotated[Session,Depends(get_session)]):
    del user; item=session.get(UserDocument,document_id)
    if item is None: raise HTTPException(404,"سند پیدا نشد")
    item.status=payload.status; item.admin_note=payload.admin_note; session.commit(); return {"ok":True}


@admin_router.get("/tickets")
def admin_tickets(user:Annotated[User,Depends(require_permissions("tickets:manage"))],session:Annotated[Session,Depends(get_session)]):
    del user; return [ticket_data(t) for t in session.scalars(select(SupportTicket).options(selectinload(SupportTicket.messages)).order_by(SupportTicket.updated_at.desc()))]


@admin_router.post("/tickets/{ticket_id}/reply")
def admin_ticket_reply(ticket_id:str,payload:MessageCreate,user:Annotated[User,Depends(require_permissions("tickets:manage"))],session:Annotated[Session,Depends(get_session)]):
    ticket=session.get(SupportTicket,ticket_id)
    if ticket is None: raise HTTPException(404,"تیکت پیدا نشد")
    session.add(TicketMessage(ticket_id=ticket.id,sender_user_id=user.id,message=payload.message,is_staff=True)); ticket.status="answered"; session.commit(); return {"ok":True}


@admin_router.patch("/tickets/{ticket_id}")
def update_ticket(ticket_id: str, payload: TicketAdminUpdate, user: Annotated[User, Depends(require_permissions("tickets:manage"))], session: Annotated[Session, Depends(get_session)]):
    del user
    ticket = session.get(SupportTicket, ticket_id)
    if ticket is None:
        raise HTTPException(404, "تیکت پیدا نشد")
    ticket.status = payload.status; session.commit()
    return {"ok": True}


@admin_router.get("/chats")
def admin_chats(user:Annotated[User,Depends(require_permissions("chats:manage"))],session:Annotated[Session,Depends(get_session)]):
    del user; rows=session.execute(select(Conversation,User.email).join(User,User.id==Conversation.user_id).where(Conversation.deleted_at.is_(None)).order_by(Conversation.updated_at.desc()).limit(200)); return [{"id":c.id,"email":email,"title":c.title,"created_at":c.created_at,"updated_at":c.updated_at,"message_count":session.scalar(select(func.count(ChatMessage.id)).where(ChatMessage.conversation_id==c.id)) or 0} for c,email in rows]


@admin_router.get("/chats/{conversation_id}")
def admin_chat_messages(conversation_id: str, user: Annotated[User, Depends(require_permissions("chats:manage"))], session: Annotated[Session, Depends(get_session)]):
    del user
    conversation = session.get(Conversation, conversation_id)
    if conversation is None or conversation.deleted_at is not None:
        raise HTTPException(404, "گفتگو پیدا نشد")
    return [{"id": message.id, "role": message.role, "content": message.content, "created_at": message.created_at} for message in session.scalars(select(ChatMessage).where(ChatMessage.conversation_id == conversation_id).order_by(ChatMessage.created_at))]


@admin_router.delete("/chats/{conversation_id}", status_code=204)
def admin_delete_chat(conversation_id: str, user: Annotated[User, Depends(require_permissions("chats:manage"))], session: Annotated[Session, Depends(get_session)]):
    del user
    conversation = session.get(Conversation, conversation_id)
    if conversation is None:
        raise HTTPException(404, "گفتگو پیدا نشد")
    conversation.deleted_at = datetime.now(timezone.utc); session.commit()


@admin_router.get("/profiles")
def admin_profiles(user: Annotated[User, Depends(require_permissions("users:manage"))], session: Annotated[Session, Depends(get_session)]):
    del user
    rows = session.execute(select(User, UserProfile).outerjoin(UserProfile, UserProfile.user_id == User.id).order_by(User.created_at.desc()))
    return [{"id": account.id, "full_name": account.full_name, "email": account.email, "tier": account.account_tier, "is_active": account.is_active, "phone": profile.phone if profile else "", "province": profile.province if profile else "", "city": profile.city if profile else "", "company_name": profile.company_name if profile else "", "job_title": profile.job_title if profile else "", "profile_score": profile.profile_score if profile else 10, "reward_points": profile.reward_points if profile else 0} for account, profile in rows]


@admin_router.get("/discounts")
def admin_discounts(user: Annotated[User, Depends(require_permissions("payments:manage"))], session: Annotated[Session, Depends(get_session)]):
    del user
    return [{"id": item.id, "code": item.code, "percent": item.percent, "max_uses": item.max_uses, "used_count": item.used_count, "is_active": item.is_active, "expires_at": item.expires_at} for item in session.scalars(select(DiscountCode).order_by(DiscountCode.created_at.desc()))]


@admin_router.post("/discounts", status_code=201)
def create_discount(payload: DiscountCreate, user: Annotated[User, Depends(require_permissions("payments:manage"))], session: Annotated[Session, Depends(get_session)]):
    del user
    code = payload.code.strip().upper()
    if session.scalar(select(DiscountCode).where(DiscountCode.code == code)):
        raise HTTPException(409, "این کد تخفیف قبلاً ساخته شده است")
    item = DiscountCode(code=code, percent=payload.percent, max_uses=payload.max_uses, is_active=payload.is_active)
    session.add(item); session.commit(); session.refresh(item)
    return {"id": item.id, "code": item.code}


@admin_router.patch("/discounts/{discount_id}")
def update_discount(discount_id: str, payload: DiscountUpdate, user: Annotated[User, Depends(require_permissions("payments:manage"))], session: Annotated[Session, Depends(get_session)]):
    del user
    item = session.get(DiscountCode, discount_id)
    if item is None:
        raise HTTPException(404, "کد تخفیف پیدا نشد")
    for key, value in payload.model_dump(exclude_none=True).items():
        setattr(item, key, value)
    session.commit()
    return {"ok": True}
