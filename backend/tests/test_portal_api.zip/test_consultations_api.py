import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.core.config import Settings
from app.db.base import Base
from app.main import create_app
from app.models.auth import Role, User
from app.repositories.auth import seed_rbac

PASSWORD = "SecurePassword123"


@pytest.fixture
def consultation_client(tmp_path):
    settings = Settings(
        environment="test",
        database_url=f"sqlite+pysqlite:///{(tmp_path / 'consultations.db').as_posix()}",
        jwt_secret="test-secret-that-is-at-least-32-characters-long",
        local_storage_path=str(tmp_path / "storage"),
        log_level="CRITICAL",
    )
    app = create_app(settings)
    with TestClient(app) as client:
        Base.metadata.create_all(app.state.database.engine)
        with app.state.database.session() as session:
            seed_rbac(session)
        yield app, client


def register(client, email):
    client.post(
        "/auth/register",
        json={"email": email, "password": PASSWORD, "full_name": "کاربر آزمون"},
    )
    token = client.post(
        "/auth/login", json={"email": email, "password": PASSWORD}
    ).json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def login(client, email):
    token = client.post(
        "/auth/login", json={"email": email, "password": PASSWORD}
    ).json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_consultation_owner_and_manager_workflow(consultation_client):
    app, client = consultation_client
    owner_headers = register(client, "owner@example.com")
    manager_headers = register(client, "expert@example.com")
    with app.state.database.session() as session:
        manager = session.scalar(select(User).where(User.email == "expert@example.com"))
        role = session.scalar(select(Role).where(Role.name == "tax_expert"))
        manager.roles = [role]
        manager_id = manager.id
        session.commit()
    manager_headers = login(client, "expert@example.com")
    created = client.post(
        "/api/v1/consultations",
        headers=owner_headers,
        json={
            "subject": "بررسی مهلت اعتراض",
            "description": "برای یک ابلاغ مالیاتی نیاز به بررسی تخصصی دارم.",
        },
    )
    assert created.status_code == 201, created.text
    consultation = created.json()
    assert consultation["status"] == "submitted"
    queue = client.get(
        "/api/v1/consultations/manage/all", headers=manager_headers
    )
    assert queue.status_code == 200
    updated = client.patch(
        f"/api/v1/consultations/manage/{consultation['id']}",
        headers=manager_headers,
        json={
            "status": "resolved",
            "priority": "high",
            "assigned_to": manager_id,
            "internal_note": "یادداشت داخلی",
            "resolution": "نتیجه بررسی تخصصی ثبت شد.",
            "note": "پرونده بسته شد",
        },
    )
    assert updated.status_code == 200, updated.text
    assert updated.json()["internal_note"] == "یادداشت داخلی"
    owner_view = client.get(
        f"/api/v1/consultations/{consultation['id']}", headers=owner_headers
    )
    assert owner_view.status_code == 200
    assert owner_view.json()["resolution"]
    assert "internal_note" not in owner_view.json()


def test_user_cannot_access_another_users_consultation(consultation_client):
    _app, client = consultation_client
    first = register(client, "first-consult@example.com")
    second = register(client, "second-consult@example.com")
    item = client.post(
        "/api/v1/consultations",
        headers=first,
        json={"subject": "موضوع مالیاتی", "description": "شرح کافی برای درخواست مشاور مالیاتی"},
    ).json()
    response = client.get(f"/api/v1/consultations/{item['id']}", headers=second)
    assert response.status_code == 404


def test_consultant_only_sees_assigned_cases(consultation_client):
    app, client = consultation_client
    owner = register(client, "assigned-owner@example.com")
    consultant_headers = register(client, "assigned-consultant@example.com")
    support_headers = register(client, "assigned-support@example.com")
    with app.state.database.session() as session:
        consultant = session.scalar(select(User).where(User.email == "assigned-consultant@example.com"))
        consultant.roles = [session.scalar(select(Role).where(Role.name == "consultant"))]
        support = session.scalar(select(User).where(User.email == "assigned-support@example.com"))
        support.roles = [session.scalar(select(Role).where(Role.name == "support_admin"))]
        consultant_id = consultant.id
        session.commit()
    consultant_headers = login(client, "assigned-consultant@example.com")
    support_headers = login(client, "assigned-support@example.com")
    first = client.post("/api/v1/consultations", headers=owner, json={"subject": "پرونده اول", "description": "شرح کامل پرونده مالیاتی اول برای بررسی مشاور"}).json()
    client.post("/api/v1/consultations", headers=owner, json={"subject": "پرونده دوم", "description": "شرح کامل پرونده مالیاتی دوم برای بررسی مشاور"})
    assigned = client.patch(f"/api/v1/consultations/manage/{first['id']}", headers=support_headers, json={"status": "in_review", "priority": "normal", "assigned_to": consultant_id, "internal_note": "", "resolution": "", "note": "ارجاع"})
    assert assigned.status_code == 200, assigned.text
    queue = client.get("/api/v1/consultations/assigned/me", headers=consultant_headers)
    assert queue.status_code == 200
    assert [item["id"] for item in queue.json()] == [first["id"]]
