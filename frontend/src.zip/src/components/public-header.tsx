import Link from "next/link";
import { SiteBrand } from "@/components/site-theme-provider";

export function PublicHeader() {
  return <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6"><Link href="/" className="flex items-center gap-3 font-black"><SiteBrand /></Link><nav className="hidden items-center gap-6 text-sm md:flex"><Link href="/laws">قوانین مالیاتی</Link><Link href="/pricing">تعرفه‌ها</Link><Link href="/about">درباره ما</Link><Link href="/contact">تماس</Link></nav><Link href="/login" className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">ورود به سامانه</Link></header>;
}
