"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { BadgeCheck, BarChart3, Bell, BookOpen, Bot, CalendarDays, Camera, ClipboardCheck, ContactRound, CreditCard, Database, FileText, Headphones, History, LayoutDashboard, LogOut, Menu, MessageCircle, MessageCircleQuestion, Newspaper, Phone, Scale, Send, Settings, ShieldCheck, Tags, TicketCheck, UploadCloud, UserCog, UserPlus, Users, WalletCards, Wrench, X } from "lucide-react";
import { api } from "@/lib/api";
import type { User } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useSiteConfiguration } from "@/components/site-theme-provider";

const navigation = [
  { href: "/app/dashboard", label: "صفحه اصلی", icon: LayoutDashboard },
  { href: "/app/chat", label: "گفت‌وگوی مالیاتی", icon: MessageCircleQuestion },
  { href: "/app/history", label: "تاریخچه گفتگو", icon: History },
  { href: "/app/calendar", label: "تقویم و اعلان‌ها", icon: CalendarDays },
  { href: "/app/notifications", label: "اعلان‌های سامانه", icon: Bell },
  { href: "/app/tools", label: "ابزارهای مالیاتی", icon: Wrench },
  { href: "/app/laws", label: "مرکز قوانین", icon: BookOpen },
  { href: "/app/usage", label: "مصرف و امتیاز", icon: BarChart3 },
  { href: "/app/plans", label: "اشتراک و پرداخت", icon: CreditCard },
  { href: "/app/wallet", label: "کیف پول", icon: WalletCards },
  { href: "/app/documents", label: "اسناد من", icon: UploadCloud },
  { href: "/app/tickets", label: "چت پشتیبانی", icon: TicketCheck },
  { href: "/app/consultations", label: "مرکز مشاوران", icon: Headphones },
  { href: "/app/consultant-verification", label: "همکاری به‌عنوان مشاور", icon: BadgeCheck },
  { href: "/app/profile", label: "پروفایل و امتیاز", icon: UserCog },
  { href: "/app/security", label: "امنیت حساب", icon: ShieldCheck },
];

const managedNavigation = [
  { href: "/management", label: "مرکز کنترل سایت", icon: LayoutDashboard, permission: "users:manage" },
  { href: "/management/users", label: "مدیریت کاربران", icon: Users, permission: "users:manage" },
  { href: "/management/profiles", label: "اطلاعات کاربران", icon: ContactRound, permission: "users:manage" },
  { href: "/management/consultants", label: "مدیریت مشاوران", icon: BadgeCheck, permission: "users:manage" },
  { href: "/management/consultants/new", label: "افزودن مشاور", icon: UserPlus, permission: "users:manage" },
  { href: "/management/payments", label: "پرداخت‌ها", icon: WalletCards, permission: "payments:manage" },
  { href: "/management/consultant-settlements", label: "تسویه مشاوران", icon: WalletCards, permission: "payments:manage" },
  { href: "/management/reports", label: "گزارش مالی و مصرف", icon: BarChart3, permission: "users:manage" },
  { href: "/management/announcements", label: "اعلان عمومی", icon: Bell, permission: "notifications:manage" },
  { href: "/management/audit", label: "فعالیت مدیران", icon: History, permission: "audit:read" },
  { href: "/management/wallets", label: "کیف پول کاربران", icon: WalletCards, permission: "payments:manage" },
  { href: "/management/discounts", label: "کدهای تخفیف", icon: Tags, permission: "payments:manage" },
  { href: "/management/subscriptions", label: "اشتراک‌ها", icon: CreditCard, permission: "subscriptions:manage" },
  { href: "/management/customer-documents", label: "اسناد کاربران", icon: FileText, permission: "user_documents:manage" },
  { href: "/management/datasets", label: "دیتاست و بانک دانش", icon: Database, permission: "documents:manage" },
  { href: "/management/laws", label: "مدیریت قوانین", icon: BookOpen, permission: "documents:manage" },
  { href: "/management/content", label: "صفحات و بلاگ", icon: Newspaper, permission: "site:manage" },
  { href: "/management/tickets", label: "تیکت‌ها", icon: TicketCheck, permission: "tickets:manage" },
  { href: "/management/consultations", label: "مدیریت مشاوره‌ها", icon: ClipboardCheck, permission: "consultations:manage" },
  { href: "/management/chats", label: "نظارت گفتگوها", icon: MessageCircleQuestion, permission: "chats:manage" },
  { href: "/management/settings#ai-model", label: "مدل هوش مصنوعی", icon: Bot, permission: "site:manage" },
  { href: "/management/settings", label: "تنظیمات کل سامانه", icon: Settings, permission: "site:manage" },
];

const supportNavigation = [
  { href: "/support", label: "داشبورد پاسخ‌گویی", icon: LayoutDashboard, permission: "tickets:manage" },
  { href: "/support/tickets", label: "تیکت‌های کاربران", icon: TicketCheck, permission: "tickets:manage" },
  { href: "/support/consultations", label: "ارجاع به کارشناس", icon: ClipboardCheck, permission: "consultations:manage" },
  { href: "/support/consultants", label: "افزودن مشاور", icon: UserPlus, permission: "consultations:manage" },
  { href: "/support/consultant-approvals", label: "صلاحیت و حذف مشاوران", icon: BadgeCheck, permission: "consultations:manage" },
  { href: "/support/consultant-settlements", label: "تسویه مشاوران", icon: WalletCards, permission: "payments:manage" },
  { href: "/support/documents", label: "مدارک کاربران", icon: FileText, permission: "user_documents:manage" },
  { href: "/support/payments", label: "پرداخت و بازپرداخت", icon: WalletCards, permission: "payments:manage" },
  { href: "/support/announcements", label: "ارسال اعلان", icon: Bell, permission: "notifications:manage" },
];

const expertNavigation = [
  { href: "/consultant", label: "میزکار مشاور", icon: LayoutDashboard, permission: "consultations:handle" },
  { href: "/consultant/profile", label: "پروفایل حرفه‌ای", icon: UserCog, permission: "consultations:handle" },
  { href: "/consultant/tickets", label: "تیکت‌ها", icon: TicketCheck, permission: "tickets:manage" },
];

const roleLabels: Record<string, string> = { system_admin: "مدیر سامانه", admin: "ادمین", tax_expert: "کارشناس مالی", company_expert: "کارشناس شرکت", user: "کاربر" };
const tierLabels = { normal: "عادی", plus: "پلاس", pro: "حرفه‌ای" };

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const { branding } = useSiteConfiguration();

  useEffect(() => {
    const loadUser = () => api<User>("users/me").then((currentUser) => {
      setUser(currentUser);
      const panel = currentUser.roles.includes("system_admin") ? "/management" : currentUser.roles.includes("admin") ? "/support" : currentUser.roles.includes("company_expert") || currentUser.roles.includes("tax_expert") ? "/consultant" : "/app";
      if (!pathname.startsWith(panel)) router.replace(panel === "/app" ? "/app/dashboard" : panel);
    }).catch(() => router.replace("/login"));
    void loadUser();
    window.addEventListener("focus", loadUser);
    return () => window.removeEventListener("focus", loadUser);
  }, [pathname, router]);

  async function logout() { await fetch("/api/auth/logout", { method: "POST" }); window.location.assign("/login"); }
  if (!user) return <div className="flex min-h-screen items-center justify-center bg-sky-50 text-sm text-slate-500">در حال آماده‌سازی چکاه...</div>;

  const role = user.roles.includes("system_admin") ? "system_admin" : user.roles.includes("admin") ? "admin" : user.roles.includes("company_expert") ? "company_expert" : user.roles.includes("tax_expert") ? "tax_expert" : "user";
  if (role === "user") return <UserShell user={user} branding={branding} pathname={pathname} menuOpen={menuOpen} setMenuOpen={setMenuOpen} logout={logout}>{children}</UserShell>;

  const visibleNavigation = role === "admin" ? supportNavigation.filter((item) => user.permissions.includes(item.permission)) : ["company_expert", "tax_expert"].includes(role) ? expertNavigation.filter((item) => user.permissions.includes(item.permission)) : managedNavigation.filter((item) => user.permissions.includes(item.permission));
  return <div className="site-surface min-h-screen lg:grid lg:grid-cols-[280px_1fr]"><aside className="border-l border-white/25 bg-gradient-to-b from-cyan-500 via-blue-600 to-indigo-700 p-5 text-white shadow-2xl shadow-blue-950/20 lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col"><Brand branding={branding} subtitle="مرکز مدیریت و پاسخ‌گویی" /><nav className="grid grid-cols-2 gap-2 lg:min-h-0 lg:flex-1 lg:grid-cols-1 lg:overflow-y-auto lg:[scrollbar-width:none] lg:[&::-webkit-scrollbar]:hidden">{visibleNavigation.map((item) => <NavigationLink key={item.href} item={item} active={isNavigationActive(pathname, item.href)} />)}</nav><Account user={user} role={role} logout={logout} /></aside><main className="min-w-0 p-4 sm:p-7 lg:p-10"><div className="mx-auto max-w-6xl">{children}</div></main></div>;
}

type Branding = { site_name: string; short_description: string; logo_url: string; support_email: string; support_phone: string; instagram_url: string; whatsapp_url: string; telegram_url: string };

function UserShell({ user, branding, pathname, menuOpen, setMenuOpen, logout, children }: { user: User; branding: Branding; pathname: string; menuOpen: boolean; setMenuOpen: (value: boolean) => void; logout: () => void; children: React.ReactNode }) {
  return <div className="site-surface min-h-screen">
    <header className="sticky top-0 z-40 border-b border-sky-100 bg-white"><div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6"><div className="flex items-center gap-3"><Button type="button" variant="outline" size="icon" className="size-11 rounded-2xl border-sky-200 bg-sky-50 text-blue-700" onClick={() => setMenuOpen(true)} aria-label="بازکردن منو"><Menu /></Button><Link href="/app/dashboard" className="flex items-center gap-3"><Logo branding={branding} /><div><p className="font-black text-slate-900">{branding.site_name}</p><p className="hidden text-[11px] text-slate-500 sm:block">{branding.short_description}</p></div></Link></div><div className="flex items-center gap-2"><a href="#contact" className="hidden px-2 text-xs font-bold text-slate-500 transition hover:text-blue-600 md:block">ارتباط با ما</a><Link href="/app/chat" className="hidden rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-blue-700 sm:block">پرسش جدید</Link><Link href="/app/profile" className="flex items-center gap-2 rounded-2xl border border-sky-100 bg-white p-1.5 pl-3 shadow-sm"><Avatar className="size-9"><AvatarFallback className="bg-gradient-to-br from-amber-300 to-orange-400 text-slate-900">{user.full_name.slice(0, 1)}</AvatarFallback></Avatar><div className="hidden text-right md:block"><p className="max-w-32 truncate text-xs font-bold">{user.full_name}</p><p className="text-[10px] text-blue-600">پلن {tierLabels[user.account_tier]}</p></div></Link></div></div></header>
    <div className={cn("fixed inset-0 z-50 transition", menuOpen ? "visible" : "invisible")}><button type="button" aria-label="بستن منو" onClick={() => setMenuOpen(false)} className={cn("absolute inset-0 bg-blue-950/30 backdrop-blur-sm transition-opacity", menuOpen ? "opacity-100" : "opacity-0")} /><aside className={cn("absolute right-0 top-0 flex h-full w-[min(92vw,420px)] flex-col overflow-hidden bg-white p-4 shadow-2xl transition-transform duration-300", menuOpen ? "translate-x-0" : "translate-x-full")}><div className="flex items-center justify-between"><Brand branding={branding} subtitle="دسترسی سریع به همه خدمات" compact /><Button type="button" variant="ghost" size="icon" onClick={() => setMenuOpen(false)}><X /></Button></div><nav className="mt-4 grid min-h-0 flex-1 grid-cols-2 content-start gap-1.5">{navigation.map((item) => <Link onClick={() => setMenuOpen(false)} key={item.href} href={item.href} className={cn("flex min-h-12 items-center gap-2 rounded-xl px-3 py-2 text-xs transition", pathname === item.href || pathname.startsWith(`${item.href}/`) ? "bg-gradient-to-l from-blue-600 to-cyan-500 font-bold text-white shadow-lg shadow-blue-600/20" : "text-slate-600 hover:bg-sky-50 hover:text-blue-700")}><item.icon className="size-4 shrink-0" /><span>{item.label}</span></Link>)}</nav><div className="mt-3 rounded-2xl bg-sky-50 p-3"><div className="flex items-center justify-between"><div><p className="text-sm font-bold">{user.full_name}</p><p className="mt-1 text-xs text-slate-500">پلن اشتراک {tierLabels[user.account_tier]}</p></div><Button type="button" variant="ghost" size="icon" onClick={logout} title="خروج"><LogOut /></Button></div></div></aside></div>
    <main className="mx-auto min-h-[70vh] max-w-7xl px-4 py-7 sm:px-6 sm:py-10">{children}</main><UserFooter branding={branding} /><ContactStrip branding={branding} />
  </div>;
}

function UserFooter({ branding }: { branding: Branding }) { return <footer id="contact" className="mt-12 scroll-mt-24 border-t border-sky-100 bg-white"><div className="mx-auto grid max-w-7xl gap-10 px-5 py-12 md:grid-cols-[1.3fr_.7fr_1fr]"><div><Brand branding={branding} subtitle={branding.short_description} compact /><div className="group relative mt-5 w-fit"><button type="button" className="flex items-center gap-2 rounded-xl bg-sky-50 px-3 py-2 text-sm font-bold text-blue-700"><ContactRound className="size-4" /> درباره ما</button><div className="invisible absolute bottom-[calc(100%+10px)] right-0 z-20 w-72 translate-y-2 rounded-2xl border border-sky-100 bg-white p-4 opacity-0 shadow-2xl transition group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100"><p className="text-xs leading-6 text-slate-500">چکاه برای ساده‌کردن امور مالیاتی، دسترسی به ابزارها و ارتباط سریع با کارشناسان ساخته شده است.</p><div className="mt-4 flex gap-2"><ContactLinks branding={branding} /></div></div></div><p className="mt-4 max-w-md text-sm leading-7 text-slate-500">دسترسی ساده به ابزارهای مالیاتی، بانک دانش، پیگیری پرونده و ارتباط با کارشناسان در یک محیط امن و یکپارچه.</p></div><div><p className="font-bold">دسترسی سریع</p><div className="mt-4 grid gap-3 text-sm text-slate-500"><Link href="/app/plans">پلن‌های اشتراک</Link><Link href="/app/tickets">مرکز پشتیبانی</Link><Link href="/app/security">امنیت حساب</Link></div></div><div><p className="font-bold">اعتماد و شفافیت</p><div className="mt-4 grid grid-cols-3 gap-2"><Trust icon={ShieldCheck} label="حفاظت داده" /><Trust icon={Scale} label="پاسخ مستند" /><Trust icon={ContactRound} label="پشتیبانی" /></div><p className="mt-3 text-[11px] leading-5 text-slate-400">جایگاه نمایش مجوزها و نمادهای رسمی پس از دریافت و تأیید نهایی.</p></div></div><div className="border-t border-sky-50 px-5 py-5 text-center text-xs text-slate-400">© {new Date().getFullYear()} {branding.site_name}؛ همه حقوق محفوظ است.</div></footer>; }
function SocialLink({ icon: Icon, label, href, color }: { icon: typeof Camera; label: string; href: string; color: string }) { return href ? <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel={href.startsWith("http") ? "noreferrer" : undefined} aria-label={label} title={label} className={`flex size-10 items-center justify-center rounded-xl border border-slate-100 text-slate-500 transition ${color}`}><Icon className="size-5" /></a> : <span aria-label={`${label} ثبت نشده`} title={`${label} هنوز ثبت نشده است`} className="flex size-10 cursor-not-allowed items-center justify-center rounded-xl border border-slate-100 text-slate-300"><Icon className="size-5" /></span>; }
function ContactLinks({ branding }: { branding: Branding }) { return <><SocialLink icon={Camera} label="اینستاگرام" href={branding.instagram_url} color="hover:bg-rose-50 hover:text-rose-600" /><SocialLink icon={MessageCircle} label="واتساپ" href={branding.whatsapp_url} color="hover:bg-emerald-50 hover:text-emerald-600" /><SocialLink icon={Send} label="تلگرام" href={branding.telegram_url} color="hover:bg-sky-50 hover:text-sky-600" /><SocialLink icon={Phone} label="تماس تلفنی" href={branding.support_phone ? `tel:${branding.support_phone}` : ""} color="hover:bg-amber-50 hover:text-amber-600" /></>; }
function ContactStrip({ branding }: { branding: Branding }) { return <section id="contact-links" className="border-t border-sky-100 bg-sky-50/70"><div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-5 px-5 py-7 sm:flex-row"><div><p className="text-sm font-black text-slate-900">ارتباط با ما</p><p className="mt-1 text-xs text-slate-500">برای پرسش، پیگیری یا دریافت راهنمایی با چکاه در ارتباط باشید.</p></div><div className="flex items-center gap-2"><ContactLinks branding={branding} /></div></div></section>; }
function Trust({ icon: Icon, label }: { icon: typeof ShieldCheck; label: string }) { return <div className="flex min-h-24 flex-col items-center justify-center rounded-2xl border border-sky-100 bg-sky-50/70 p-2 text-center"><Icon className="mb-2 size-6 text-blue-600" /><span className="text-[10px] text-slate-600">{label}</span></div>; }
function NavigationLink({ item, active }: { item: { href: string; label: string; icon: typeof LayoutDashboard }; active: boolean }) { return <Link href={item.href} className={cn("flex items-center gap-3 rounded-xl px-3 py-3 text-sm transition", active ? "bg-white text-blue-700 shadow-lg shadow-blue-950/20" : "text-blue-50 hover:bg-white/15 hover:text-white")}><item.icon className="size-4.5" /><span>{item.label}</span></Link>; }
function isNavigationActive(pathname: string, href: string) {
  const isPanelRoot = ["/management", "/support", "/consultant"].includes(href);
  return pathname === href || (!isPanelRoot && pathname.startsWith(`${href}/`));
}
function Logo({ branding }: { branding: { logo_url: string } }) { return <div className="flex size-11 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-500 text-white shadow-lg shadow-blue-600/20" style={branding.logo_url ? { backgroundImage: `url(${branding.logo_url})`, backgroundPosition: "center", backgroundRepeat: "no-repeat", backgroundSize: "contain" } : undefined}>{branding.logo_url ? null : <Scale />}</div>; }
function Brand({ branding, subtitle, compact = false }: { branding: { site_name: string; logo_url: string }; subtitle: string; compact?: boolean }) { return <div className={cn("flex items-center gap-3", compact ? "" : "mb-8 px-2")}><Logo branding={branding} /><div><p className="font-bold">{branding.site_name}</p><p className="text-xs opacity-70">{subtitle}</p></div></div>; }
function Account({ user, role, logout }: { user: User; role: string; logout: () => void }) { return <div className="mt-5 rounded-2xl border border-white/25 bg-white/15 p-4"><div className="flex items-center gap-3"><Avatar><AvatarFallback className="bg-amber-300 text-blue-950">{user.full_name.slice(0, 1)}</AvatarFallback></Avatar><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-white">{user.full_name}</p><Badge variant="secondary" className="mt-1 text-[10px]">{roleLabels[role]}</Badge></div><Button type="button" variant="ghost" size="icon" className="text-white hover:bg-white/15" onClick={logout}><LogOut /></Button></div></div>; }
