"use client";

import { useEffect, useState } from "react";
import { CheckCircle2, Copy, KeyRound, ShieldCheck } from "lucide-react";
import { api, ApiError } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

type Setup = { enabled: boolean; secret: string; otpauth_uri: string };

export default function SecurityPage() {
  const [setup, setSetup] = useState<Setup | null>(null); const [code, setCode] = useState(""); const [message, setMessage] = useState("");
  const load = () => api<Setup>("api/v1/tools/security/2fa/setup").then(setSetup);
  useEffect(() => { void load(); }, []);
  async function enable() { setMessage(""); try { await api("api/v1/tools/security/2fa/enable", { method: "POST", body: JSON.stringify({ code }) }); setCode(""); setMessage("ورود دومرحله‌ای فعال شد."); await load(); } catch (error) { setMessage(error instanceof ApiError ? error.message : "فعال‌سازی انجام نشد."); } }
  async function disable() { setMessage(""); try { await api("api/v1/tools/security/2fa", { method: "DELETE", body: JSON.stringify({ code }) }); setCode(""); setMessage("ورود دومرحله‌ای غیرفعال شد."); await load(); } catch (error) { setMessage(error instanceof ApiError ? error.message : "غیرفعال‌سازی انجام نشد."); } }
  return <div className="mx-auto max-w-3xl space-y-7"><header><p className="text-sm font-medium text-primary">حفاظت از حساب</p><h1 className="mt-1 text-3xl font-black">امنیت و ورود دومرحله‌ای</h1><p className="mt-2 text-muted-foreground">حتی در صورت افشای رمز عبور، از ورود غیرمجاز جلوگیری کنید.</p></header><Card className="overflow-hidden border-white/70 bg-white/90"><div className="h-2 bg-gradient-to-l from-primary to-teal-300" /><CardHeader><div className="flex items-center justify-between"><div className="flex size-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><ShieldCheck className="size-7" /></div><Badge variant={setup?.enabled ? "default" : "secondary"}>{setup?.enabled ? "فعال" : "غیرفعال"}</Badge></div><CardTitle className="pt-3">برنامه احراز هویت</CardTitle><CardDescription>از Google Authenticator، Microsoft Authenticator یا برنامه مشابه استفاده کنید.</CardDescription></CardHeader><CardContent className="space-y-5">{!setup?.enabled && <div className="rounded-2xl bg-slate-950 p-5 text-white"><p className="text-xs text-slate-400">کلید راه‌اندازی را در برنامه وارد کنید</p><div className="mt-3 flex items-center gap-2"><code className="min-w-0 flex-1 break-all text-lg tracking-wider text-teal-300">{setup?.secret}</code><Button size="icon" variant="secondary" onClick={() => navigator.clipboard.writeText(setup?.secret ?? "")}><Copy /></Button></div></div>}<div><p className="mb-2 text-sm font-medium">کد ۶ رقمی برنامه</p><div className="flex gap-2"><div className="relative flex-1"><KeyRound className="absolute right-3 top-3 size-4 text-muted-foreground" /><Input className="pr-10 text-center font-mono tracking-[.35em]" dir="ltr" inputMode="numeric" value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="000000" /></div><Button disabled={code.length !== 6} variant={setup?.enabled ? "destructive" : "default"} onClick={setup?.enabled ? disable : enable}>{setup?.enabled ? "غیرفعال‌سازی" : "تأیید و فعال‌سازی"}</Button></div></div>{message && <p className="flex items-center gap-2 rounded-xl bg-primary/5 p-3 text-sm text-primary"><CheckCircle2 className="size-4" />{message}</p>}<p className="text-xs leading-6 text-muted-foreground">پس از فعال‌سازی، هنگام ورود علاوه بر رمز عبور باید کد برنامه را نیز وارد کنید.</p></CardContent></Card></div>;
}
