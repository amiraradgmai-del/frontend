"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { AdminTable } from "@/components/admin-table";

type ProfileRow = {
  id: string; full_name: string; email: string; tier: string; is_active: boolean;
  phone: string; province: string; city: string; company_name: string;
  job_title: string; profile_score: number; reward_points: number;
};

export default function ProfilesPage() {
  const [rows, setRows] = useState<ProfileRow[]>([]);
  useEffect(() => { api<ProfileRow[]>("api/v1/admin/profiles").then(setRows); }, []);
  return <AdminTable title="اطلاعات کاربران" subtitle="پروفایل، موقعیت، کسب‌وکار و امتیاز وفاداری کاربران" headers={["کاربر", "تماس", "کسب‌وکار", "موقعیت", "پلن", "تکمیل", "امتیاز"]}>
    {rows.map((row) => <tr key={row.id} className="border-t align-top transition hover:bg-slate-50/70">
      <td className="p-4"><p className="font-semibold">{row.full_name}</p><p className="mt-1 text-xs text-muted-foreground" dir="ltr">{row.email}</p></td>
      <td className="p-4" dir="ltr">{row.phone || "—"}</td>
      <td className="p-4"><p>{row.company_name || "—"}</p><p className="text-xs text-muted-foreground">{row.job_title}</p></td>
      <td className="p-4">{[row.province, row.city].filter(Boolean).join("، ") || "—"}</td>
      <td className="p-4"><Badge variant="outline">{row.tier}</Badge></td>
      <td className="p-4"><span className="font-bold text-primary">{row.profile_score}%</span></td>
      <td className="p-4">{row.reward_points.toLocaleString("fa-IR")}</td>
    </tr>)}
  </AdminTable>;
}
