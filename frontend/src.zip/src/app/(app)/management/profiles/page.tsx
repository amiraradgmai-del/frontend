export { default } from "@/app/(app)/admin/profiles/page";
