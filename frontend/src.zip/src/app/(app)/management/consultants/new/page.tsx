export { default } from "../../../support/consultants/page";
