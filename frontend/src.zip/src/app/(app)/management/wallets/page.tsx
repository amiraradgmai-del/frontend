"use client";

import { useEffect, useState } from "react";
import { ArrowDownLeft, ArrowUpRight, Search, WalletCards } from "lucide-react";
import { api } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

type WalletSummary = { user_id: string; full_name: string; email: string; balance: number; total_deposited: number; total_spent: number; total_withdrawn: number };
type Transaction = { id: string; type: string; amount: number; status: string; reference: string; related_type: string; related_id: string | null; failure_reason: string; created_at: string };
type WalletDetails = { user_id: string; full_name: string; email: string; balance: number; transactions: Transaction[] };

export default function WalletManagementPage() {
  const [items, setItems] = useState<WalletSummary[]>([]);
  const [selected, setSelected] = useState<WalletDetails | null>(null);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);

  async function load(search = "") { setLoading(true); try { setItems(await api<WalletSummary[]>(`api/v1/admin/wallets?q=${encodeURIComponent(search)}`)); } finally { setLoading(false); } }
  useEffect(() => { void api<WalletSummary[]>("api/v1/admin/wallets").then(setItems); }, []);
  async function details(userId: string) { setSelected(await api<WalletDetails>(`api/v1/admin/wallets/${userId}`)); }

  return <div className="space-y-7">
    <header><p className="text-sm font-bold text-blue-600">دفترکل مالی سامانه</p><h1 className="mt-1 text-3xl font-black">کیف پول کاربران</h1><p className="mt-2 text-slate-500">مشاهده موجودی، شارژها، پرداخت‌ها و برداشت‌ها بدون امکان تغییر مستقیم موجودی.</p></header>
    <form onSubmit={(event) => { event.preventDefault(); void load(query); }} className="flex gap-2"><label className="relative flex-1"><Search className="absolute right-3 top-3 size-4 text-slate-400" /><Input className="pr-10" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="نام یا ایمیل کاربر" /></label><Button disabled={loading}>جست‌وجو</Button></form>
    <section className="grid gap-4 md:grid-cols-2">{items.map((item) => <button type="button" onClick={() => void details(item.user_id)} key={item.user_id} className="rounded-3xl border border-sky-100 bg-white p-5 text-right shadow-sm transition hover:-translate-y-1 hover:shadow-xl"><div className="flex items-center justify-between"><div><p className="font-black">{item.full_name}</p><p dir="ltr" className="mt-1 text-left text-xs text-slate-500">{item.email}</p></div><span className="flex size-11 items-center justify-center rounded-2xl bg-blue-100 text-blue-700"><WalletCards /></span></div><p className="mt-5 text-2xl font-black text-blue-700">{item.balance.toLocaleString("fa-IR")} تومان</p><div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs"><Summary label="شارژ" value={item.total_deposited} /><Summary label="پرداخت" value={item.total_spent} /><Summary label="برداشت" value={item.total_withdrawn} /></div></button>)}</section>
    {selected && <Card className="border-sky-100 bg-white"><CardHeader><CardTitle>تراکنش‌های {selected.full_name}</CardTitle></CardHeader><CardContent className="space-y-3">{selected.transactions.map((item) => <div key={item.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border p-4"><div className="flex items-center gap-3"><span className={`flex size-10 items-center justify-center rounded-xl ${item.type === "charge" ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>{item.type === "charge" ? <ArrowDownLeft /> : <ArrowUpRight />}</span><div><p className="font-bold">{transactionLabel(item.type)}</p><p dir="ltr" className="mt-1 text-left text-xs text-slate-500">{item.reference}</p>{item.related_id && <p className="mt-1 text-[10px] text-slate-400">{item.related_type}: {item.related_id}</p>}</div></div><div className="text-left"><p className="font-black">{item.amount.toLocaleString("fa-IR")} تومان</p><Badge variant={item.status === "failed" ? "destructive" : "secondary"}>{item.status}</Badge></div></div>)}</CardContent></Card>}
  </div>;
}

function Summary({ label, value }: { label: string; value: number }) { return <div className="rounded-xl bg-sky-50 p-2"><p className="font-black text-slate-800">{value.toLocaleString("fa-IR")}</p><p className="mt-1 text-slate-500">{label}</p></div>; }
function transactionLabel(type: string) { return type === "charge" ? "شارژ کیف پول" : type === "withdraw" ? "برداشت وجه" : type === "consultation" ? "پرداخت مشاوره" : "پرداخت خدمت"; }
