"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function ForgotPasswordPage() {
  const [step, setStep] = useState<"request" | "confirm" | "done">("request");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  async function requestCode(event: FormEvent) {
    event.preventDefault(); setBusy(true); setMessage("");
    const response = await fetch("/api/backend/auth/password-reset/start", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
    setBusy(false);
    if (!response.ok) return setMessage("ارسال کد انجام نشد؛ دوباره تلاش کنید.");
    setStep("confirm"); setMessage("اگر حساب فعال باشد، کد بازیابی ارسال شده است.");
  }
  async function reset(event: FormEvent) {
    event.preventDefault(); setBusy(true); setMessage("");
    const response = await fetch("/api/backend/auth/password-reset/complete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, code, password }) });
    setBusy(false);
    if (!response.ok) return setMessage("کد منقضی یا نامعتبر است.");
    setStep("done");
  }
  return <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-sky-50 to-white p-5"><Card className="w-full max-w-md"><CardHeader><CardTitle>بازیابی رمز عبور</CardTitle><CardDescription>کد تأیید به ایمیل حساب ارسال می‌شود.</CardDescription></CardHeader><CardContent>{step === "request" && <form onSubmit={requestCode} className="space-y-4"><Input dir="ltr" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="ایمیل حساب" required /><Button className="w-full" disabled={busy}>ارسال کد بازیابی</Button></form>}{step === "confirm" && <form onSubmit={reset} className="space-y-4"><Input dir="ltr" inputMode="numeric" value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="کد ۶ رقمی" required /><Input dir="ltr" type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="رمز جدید قوی" minLength={8} required /><Button className="w-full" disabled={busy}>ثبت رمز جدید</Button></form>}{step === "done" && <div className="rounded-xl bg-emerald-50 p-5 text-center text-emerald-800"><p>رمز عبور با موفقیت تغییر کرد.</p><Link href="/login" className="mt-4 inline-block font-bold">ورود به حساب</Link></div>}{message && <p className="mt-4 rounded-xl bg-sky-50 p-3 text-sm">{message}</p>}</CardContent></Card></main>;
}
