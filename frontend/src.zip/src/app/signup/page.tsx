"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, CheckCircle2, Eye, EyeOff, KeyRound, Mail, ShieldCheck, UserRound } from "lucide-react";
import { api, ApiError } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

type Step = "details" | "verify" | "password";

const messages: Record<string, string> = {
  "Email is already registered": "این ایمیل قبلاً ثبت شده است.",
  "Please wait before requesting another code": "برای ارسال دوباره کد کمی صبر کنید.",
  "Verification email could not be sent": "ارسال ایمیل انجام نشد؛ لطفاً دوباره تلاش کنید.",
  "Invalid or expired verification code": "کد واردشده اشتباه یا منقضی شده است.",
  "Invalid or expired password setup token": "زمان تعیین رمز تمام شده؛ ثبت‌نام را دوباره شروع کنید.",
};

function errorMessage(error: unknown) {
  if (error instanceof ApiError) return messages[error.message] ?? error.message;
  return "ارتباط با سرور برقرار نشد.";
}

export default function SignupPage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>("details");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [code, setCode] = useState("");
  const [setupToken, setSetupToken] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const hidePasswordTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendSeconds, setResendSeconds] = useState(0);
  const [showResendTimer, setShowResendTimer] = useState(false);

  useEffect(() => {
    if (resendSeconds <= 0) return;
    const timer = window.setInterval(
      () => setResendSeconds((seconds) => Math.max(0, seconds - 1)),
      1000,
    );
    return () => window.clearInterval(timer);
  }, [resendSeconds]);

  async function start(event?: FormEvent) {
    event?.preventDefault();
    setError("");
    setLoading(true);
    try {
      const result = await api<{ resend_after: number }>("auth/signup/start", {
        method: "POST",
        body: JSON.stringify({ first_name: firstName, last_name: lastName, email, referral_code: referralCode }),
      });
      setResendSeconds(result.resend_after);
      setStep("verify");
    } catch (requestError) {
      setError(errorMessage(requestError));
    } finally {
      setLoading(false);
    }
  }

  async function verify(event: FormEvent) {
    event.preventDefault();
    setError("");
    setLoading(true);
    try {
      const result = await api<{ setup_token: string }>("auth/signup/verify", {
        method: "POST",
        body: JSON.stringify({ email, code }),
      });
      setSetupToken(result.setup_token);
      setStep("password");
    } catch (requestError) {
      setError(errorMessage(requestError));
    } finally {
      setLoading(false);
    }
  }

  async function complete(event: FormEvent) {
    event.preventDefault();
    setError("");
    if (password !== confirmPassword) {
      setError("رمز عبور و تکرار آن یکسان نیستند.");
      return;
    }
    if (password.length < 8 || !/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/\d/.test(password)) {
      setError("رمز باید حداقل ۸ کاراکتر و شامل حرف بزرگ انگلیسی، حرف کوچک انگلیسی و عدد باشد.");
      return;
    }
    setLoading(true);
    try {
      await api("auth/signup/complete", {
        method: "POST",
        body: JSON.stringify({ setup_token: setupToken, password }),
      });
      router.replace("/login?registered=1");
    } catch (requestError) {
      setError(errorMessage(requestError));
    } finally {
      setLoading(false);
    }
  }

  function revealPassword() {
    if (hidePasswordTimer.current) clearTimeout(hidePasswordTimer.current);
    setShowPassword(true);
    hidePasswordTimer.current = setTimeout(() => setShowPassword(false), 5000);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 p-6">
      <Card className="w-full max-w-lg border-white/70 bg-white/90 shadow-2xl shadow-slate-900/10">
        <CardHeader className="space-y-3 text-center">
          <div className="mx-auto flex size-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            {step === "details" ? <UserRound /> : step === "verify" ? <Mail /> : <KeyRound />}
          </div>
          <CardTitle className="text-2xl">ساخت حساب کاربری</CardTitle>
          <CardDescription>
            {step === "details" && "نام و ایمیل خود را وارد کنید."}
            {step === "verify" && `کد ۶ رقمی ارسال‌شده به ${email} را وارد کنید.`}
            {step === "password" && "ایمیل تأیید شد؛ حالا یک رمز عبور امن بسازید."}
          </CardDescription>
          <div className="flex justify-center gap-2 pt-2">
            {["details", "verify", "password"].map((item, index) => (
              <span key={item} className={`h-1.5 w-16 rounded-full ${["details", "verify", "password"].indexOf(step) >= index ? "bg-primary" : "bg-slate-200"}`} />
            ))}
          </div>
        </CardHeader>
        <CardContent>
          {step === "details" && (
            <form onSubmit={start} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="space-y-2 text-sm font-medium"><span>نام</span><Input value={firstName} onChange={(event) => setFirstName(event.target.value)} placeholder="نام خود را وارد کنید" required minLength={2} /></label>
                <label className="space-y-2 text-sm font-medium"><span>نام خانوادگی</span><Input value={lastName} onChange={(event) => setLastName(event.target.value)} placeholder="نام خانوادگی خود را وارد کنید" required minLength={2} /></label>
              </div>
              <label className="block space-y-2 text-sm font-medium"><span>ایمیل</span><Input dir="ltr" type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="text-left" placeholder="name@example.com" required /></label>
              <label className="block space-y-2 text-sm font-medium"><span>کد معرف <span className="font-normal text-muted-foreground">(اختیاری)</span></span><Input dir="ltr" value={referralCode} onChange={(event) => setReferralCode(event.target.value.toUpperCase())} className="text-left" placeholder="REFERRAL" maxLength={16} /></label>
              <Button type="submit" className="w-full" size="lg" disabled={loading}>{loading ? "در حال ارسال..." : <>ارسال کد تأیید <ArrowLeft /></>}</Button>
            </form>
          )}
          {step === "verify" && (
            <form onSubmit={verify} className="space-y-4">
              <Input dir="ltr" inputMode="numeric" autoComplete="one-time-code" value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))} className="h-12 text-center tracking-[.4em]" placeholder="کد ۶ رقمی" required pattern="\d{6}" />
              <div className="flex gap-3">
                <span onMouseEnter={() => setShowResendTimer(true)} onMouseLeave={() => setShowResendTimer(false)}>
                  <Button type="button" variant="outline" onClick={() => start()} disabled={loading || resendSeconds > 0}>
                    {showResendTimer && resendSeconds > 0 ? `${resendSeconds.toLocaleString("fa-IR")} ثانیه` : "ارسال دوباره"}
                  </Button>
                </span>
                <Button type="submit" className="flex-1" size="lg" disabled={loading || code.length !== 6}>{loading ? "در حال بررسی..." : "تأیید ایمیل"}</Button>
              </div>
              <p className="flex gap-2 rounded-xl bg-amber-50 p-3 text-xs leading-6 text-amber-800"><ShieldCheck className="mt-1 size-4 shrink-0" />کد را در اختیار دیگران قرار ندهید؛ پشتیبانی هرگز این کد را درخواست نمی‌کند.</p>
            </form>
          )}
          {step === "password" && (
            <form onSubmit={complete} className="space-y-4">
              <p className="flex items-center gap-2 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-700"><CheckCircle2 className="size-5" /> ایمیل شما با موفقیت تأیید شد.</p>
              <label className="block space-y-2 text-sm font-medium"><span>رمز عبور</span><Input dir="ltr" type={showPassword ? "text" : "password"} autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} required minLength={8} /></label>
              <label className="block space-y-2 text-sm font-medium"><span>تکرار رمز عبور</span><Input dir="ltr" type={showPassword ? "text" : "password"} autoComplete="new-password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} required minLength={8} /></label>
              <div className="flex items-center justify-between gap-3"><p className="text-xs leading-6 text-muted-foreground">مثال معتبر: TaxUser123</p><Button type="button" variant="outline" size="sm" onClick={showPassword ? () => setShowPassword(false) : revealPassword}>{showPassword ? <><EyeOff /> مخفی‌کردن</> : <><Eye /> نمایش ۵ ثانیه</>}</Button></div>
              <Button type="submit" className="w-full" size="lg" disabled={loading}>{loading ? "در حال ساخت حساب..." : "تکمیل ثبت‌نام"}</Button>
            </form>
          )}
          {error && <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
          <p className="mt-6 text-center text-sm text-muted-foreground">حساب دارید؟ <Link href="/login" className="font-semibold text-primary">وارد شوید</Link></p>
        </CardContent>
      </Card>
    </main>
  );
}
