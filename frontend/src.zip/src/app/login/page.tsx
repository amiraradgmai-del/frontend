"use client";

import { FormEvent, useRef, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Eye, EyeOff, KeyRound, LockKeyhole, Mail, Scale, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [needsTwoFactor, setNeedsTwoFactor] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const hidePasswordTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  function revealPassword() {
    if (hidePasswordTimer.current) clearTimeout(hidePasswordTimer.current);
    setShowPassword(true);
    hidePasswordTimer.current = setTimeout(() => setShowPassword(false), 5000);
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    setLoading(true);
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, otp_code: otpCode }),
      });
      if (!response.ok) {
        const payload = await response.json().catch(() => null);
        if (payload?.detail === "Two-factor code required") {
          setNeedsTwoFactor(true);
          setError(otpCode ? "کد احراز هویت صحیح نیست یا منقضی شده است." : "کد ۶ رقمی برنامه احراز هویت را وارد کنید.");
          return;
        }
        setError("ایمیل یا رمز عبور صحیح نیست.");
        return;
      }
      window.location.assign("/app/dashboard");
    } catch {
      setError("ارتباط با سرور برقرار نشد. دوباره تلاش کنید.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen lg:grid-cols-2">
      <section className="relative hidden overflow-hidden bg-gradient-to-br from-sky-500 via-blue-600 to-cyan-500 p-14 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(255,255,255,.28),transparent_34%),radial-gradient(circle_at_80%_80%,rgba(251,191,36,.32),transparent_32%)]" />
        <div className="relative flex items-center gap-3"><div className="size-14 overflow-hidden rounded-2xl bg-white shadow-lg"><img src="/brand/chakah-logo.png" alt="لوگوی چکاه" className="size-full object-contain" /></div><div><p className="text-lg font-bold">چکاه</p><p className="text-sm text-sky-100">دستیار هوشمند مالیاتی</p></div></div>
        <div className="relative max-w-xl"><p className="mb-5 text-sm font-bold text-amber-200">پاسخ مبتنی بر منبع، نه حدس مدل</p><h1 className="text-4xl font-black leading-[1.6]">قانون را سریع‌تر پیدا کنید و پاسخ قابل استناد بگیرید.</h1><div className="mt-10 flex gap-6 text-sm text-sky-50"><span className="flex items-center gap-2"><ShieldCheck className="size-4 text-amber-200" /> اسناد تأییدشده</span><span className="flex items-center gap-2"><ShieldCheck className="size-4 text-amber-200" /> منابع قابل‌ردیابی</span></div></div>
        <p className="relative text-xs text-sky-100">این سامانه جایگزین بررسی پرونده توسط مشاور مالیاتی نیست.</p>
      </section>
      <section className="flex items-center justify-center p-6 sm:p-12">
        <Card className="w-full max-w-md border-white/70 bg-white/85 shadow-2xl shadow-slate-900/10 backdrop-blur-xl">
          <CardHeader className="space-y-3"><div className="mb-2 flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary lg:hidden"><Scale /></div><CardTitle className="text-2xl">ورود به حساب کاربری</CardTitle><CardDescription>برای ادامه، ایمیل و رمز عبور خود را وارد کنید.</CardDescription></CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-5">
              <label className="block space-y-2 text-sm font-medium"><span>ایمیل</span><div className="relative"><Mail className="absolute right-3 top-3 size-4 text-muted-foreground" /><Input dir="ltr" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} className="pr-10 text-left" required /></div></label>
              <label className="block space-y-2 text-sm font-medium"><span>رمز عبور</span><div className="relative"><LockKeyhole className="absolute right-3 top-3 size-4 text-muted-foreground" /><Input dir="ltr" type={showPassword ? "text" : "password"} autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} className="px-10 text-left" required /><button type="button" onClick={showPassword ? () => setShowPassword(false) : revealPassword} className="absolute left-3 top-2.5 text-muted-foreground" title={showPassword ? "مخفی‌کردن رمز" : "نمایش رمز برای ۵ ثانیه"}>{showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}</button></div></label>
              <div className="text-left"><Link href="/forgot-password" className="text-xs font-semibold text-primary">رمز عبور را فراموش کرده‌اید؟</Link></div>
              {needsTwoFactor && <label className="block space-y-2 text-sm font-medium"><span>کد احراز هویت دومرحله‌ای</span><div className="relative"><KeyRound className="absolute right-3 top-3 size-4 text-muted-foreground" /><Input dir="ltr" inputMode="numeric" autoComplete="one-time-code" value={otpCode} onChange={(event) => setOtpCode(event.target.value.replace(/\D/g, "").slice(0, 6))} className="pr-10 text-center font-mono tracking-[.3em]" placeholder="000000" required /></div></label>}
              {error && <p className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
              <Button type="submit" className="w-full" size="lg" disabled={loading}>{loading ? "در حال ورود..." : <>ورود <ArrowLeft /></>}</Button>
            </form>
            <p className="mt-5 text-center text-sm text-muted-foreground">حساب ندارید؟ <Link href="/signup" className="font-semibold text-primary">ثبت‌نام کنید</Link></p>
          </CardContent>
        </Card>
      </section>
    </main>
  );
}
